"""演示 Selenium 的两个经典报错：元素还没出现就去找；页面刷新后还拿着旧元素。"""
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

BASE = "http://127.0.0.1:8000"
driver = webdriver.Chrome(service=Service(r"D:\tool\chromedriver\chromedriver.exe"))

# 先登录
driver.get(f"{BASE}/login.html")
driver.find_element(By.ID, "username").send_keys("alice")
driver.find_element(By.ID, "password").send_keys("alice123")
driver.find_element(By.CSS_SELECTOR, "button[type=submit]").click()

# 报错 1：点完登录马上找商品页的元素，页面还没跳过去
try:
    driver.find_element(By.ID, "keyword")
    print("运气好，页面已经跳过去了")
except NoSuchElementException as e:
    print("报错 1：", type(e).__name__)

WebDriverWait(driver, 10).until(lambda d: d.find_elements(By.CSS_SELECTOR, "#rows tr"))

# 报错 2：先拿到第一行，再搜索一次（列表重新渲染），旧的那一行元素已经不在页面上了
first_row = driver.find_element(By.CSS_SELECTOR, "#rows tr")
driver.find_element(By.ID, "keyword").send_keys("耳机")
driver.find_element(By.CSS_SELECTOR, "#search-form button[type=submit]").click()
WebDriverWait(driver, 10).until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "#rows tr")) == 2)
try:
    print(first_row.text)
except StaleElementReferenceException as e:
    print("报错 2：", type(e).__name__)

driver.quit()
