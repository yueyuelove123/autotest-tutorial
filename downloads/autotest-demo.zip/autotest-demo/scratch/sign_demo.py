"""手工调一次开放接口：自己算签名。"""
import hashlib
import time

import requests

BASE = "http://127.0.0.1:8000"
SECRET = "shop-secret-2026"

ts = int(time.time())                                       # 当前时间，单位秒
sign = hashlib.md5(f"{SECRET}{ts}".encode("utf-8")).hexdigest()   # md5(密钥 + 时间戳)
print("时间戳：", ts)
print("签名：", sign)

resp = requests.get(
    f"{BASE}/api/stats/orders",
    params={"x_app_key": "shop-open", "x_timestamp": ts, "x_sign": sign},
    timeout=10,
)
print(resp.status_code, resp.json())
