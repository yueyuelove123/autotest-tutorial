"""手工走一遍异步任务：提交 → 轮询 → 下载，顺便看看每一步花了多少时间。"""
import time

import requests

BASE = "http://127.0.0.1:8000"
token = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]["token"]
headers = {"token": token}

start = time.monotonic()
task = requests.post(f"{BASE}/api/reports/stock", headers=headers, timeout=10).json()["data"]
print("提交：", task)
print("马上下载：", requests.get(f"{BASE}/api/tasks/{task['taskId']}/download", headers=headers, timeout=10).json())

deadline = time.monotonic() + 10                      # 最多等 10 秒
while time.monotonic() < deadline:
    status = requests.get(f"{BASE}/api/tasks/{task['taskId']}", headers=headers, timeout=10).json()["data"]["status"]
    print(f"{time.monotonic() - start:4.1f} 秒  {status}")
    if status == "completed":
        break
    time.sleep(0.5)                                   # 别查得太勤
else:
    raise TimeoutError("10 秒还没跑完")

resp = requests.get(f"{BASE}/api/tasks/{task['taskId']}/download", headers=headers, timeout=10)
print("下载：", resp.status_code, resp.headers["Content-Disposition"])
print("前三行：", resp.content.decode("utf-8-sig").splitlines()[:3])
