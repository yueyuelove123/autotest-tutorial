"""看一眼 token 过期长什么样：登录，等 3 秒，用旧 token 访问，再用 refreshToken 换新的。

先带 SHOP_TOKEN_TTL=2 启动练习网站（token 两秒就过期），再运行这个脚本。
"""
import time

import requests

BASE = "http://127.0.0.1:8000"


def me(token):
    resp = requests.get(f"{BASE}/api/me", headers={"token": token}, timeout=10)
    return resp.status_code, resp.json()["code"], resp.json()["msg"]


login = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]
print("登录成功，拿到 token 和 refreshToken")
print("马上访问：", me(login["token"]))

time.sleep(3)
print("3 秒后再访问：", me(login["token"]))
print("用编出来的 token 访问：", me("abc123"))

resp = requests.post(f"{BASE}/api/token/refresh", json={"refreshToken": login["refreshToken"]}, timeout=10).json()
print("用 refreshToken 换新：", resp["code"], resp["msg"])
print("用新 token 访问：", me(resp["data"]["token"]))

again = requests.post(f"{BASE}/api/token/refresh", json={"refreshToken": login["refreshToken"]}, timeout=10)
print("同一个 refreshToken 再用一次：", again.status_code, again.json()["code"], again.json()["msg"])
