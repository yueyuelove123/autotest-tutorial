"""手工试一下订单导出：看看响应头和文件内容。"""
import requests

BASE = "http://127.0.0.1:8000"
token = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]["token"]
headers = {"token": token}

pen = requests.get(f"{BASE}/api/products", params={"keyword": "中性笔"}, timeout=10).json()["data"]["items"][0]
order = requests.post(f"{BASE}/api/orders", json={"items": [{"productId": pen["id"], "quantity": 2}]},
                      headers=headers, timeout=10).json()["data"]
print("刚下的订单：", order["orderNo"])

resp = requests.get(f"{BASE}/api/orders/export", headers=headers, timeout=10)
print("状态码：", resp.status_code)
print("Content-Type：", resp.headers["Content-Type"])
print("Content-Disposition：", resp.headers["Content-Disposition"])
print("开头 6 个字节：", resp.content[:6])
print("----- 按 utf-8-sig 解码 -----")
print(resp.content.decode("utf-8-sig"))
