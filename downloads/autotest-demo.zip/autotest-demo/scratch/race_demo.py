"""两个请求同时发现 token 过期，都用同一个 refreshToken 去换，会怎样？
练习网站要先用 SHOP_TOKEN_TTL=2 启动（6.4.1）。"""
import threading
import time

import requests

BASE = "http://127.0.0.1:8000"
data = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]
time.sleep(3)                                     # 等 token 过期

results = []

def refresh(tag):
    resp = requests.post(f"{BASE}/api/token/refresh",
                         json={"refreshToken": data["refreshToken"]}, timeout=10)
    body = resp.json()
    results.append((tag, body["code"], body["msg"] if body["code"] != 0 else "成功"))

threads = [threading.Thread(target=refresh, args=(i,)) for i in range(3)]
for t in threads:
    t.start()
for t in threads:
    t.join()

for tag, code, msg in sorted(results):
    print(f"线程 {tag}：code={code}，{msg}")
