# 第 8 章的定位、操作和等待示例：先登录，再在商品页、订单页上试
from playwright.sync_api import expect, sync_playwright

with sync_playwright() as p:
    # 这里不加 slow_mo：每步都慢半秒的话，数据早就加载完了，看不出等待和不等待的区别
    browser = p.chromium.launch(channel="chrome", headless=False)
    page = browser.new_page(base_url="http://127.0.0.1:8000")
    page.goto("/login.html")
    page.get_by_label("用户名").fill("alice")
    page.get_by_label("密码").fill("alice123")
    page.get_by_role("button", name="登录").click()
    expect(page.get_by_test_id("welcome")).to_have_text("欢迎，alice")

    # 等待：页面刚打开就数商品行数，和用 expect 等到之后再数
    page.goto("/products.html")
    print("刚打开时的行数：", page.get_by_test_id("product-row").count())
    expect(page.get_by_test_id("product-row")).to_have_count(10)
    print("expect 等到之后的行数：", page.get_by_test_id("product-row").count())

    # 缩小范围：先找到「无线鼠标」那一行，再找这一行里的购买按钮
    row = page.get_by_test_id("product-row").filter(has_text="无线鼠标")
    print("这一行的内容：", row.inner_text().replace("\t", " | "))
    print("这一行里购买按钮的个数：", row.get_by_role("button", name="购买").count())

    # 操作：在搜索框里按回车，和点「搜索」按钮效果一样
    page.get_by_label("关键词").fill("耳机")
    page.get_by_label("关键词").press("Enter")
    expect(page.get_by_test_id("product-row")).to_have_count(2)
    print("搜索「耳机」后的行数：", page.get_by_test_id("product-row").count())

    # 操作：订单页的下拉框
    page.goto("/orders.html")
    page.get_by_label("状态").select_option(label="已取消")
    print("下拉框现在的值：", page.get_by_label("状态").input_value())

    browser.close()
