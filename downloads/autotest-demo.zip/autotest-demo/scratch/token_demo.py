"""手工看一次 token 过期：登录、等 3 秒再查，然后用 refreshToken 换一对新的。
练习网站要先用 SHOP_TOKEN_TTL=2 启动（6.4.1）。"""
import time

import requests

BASE = "http://127.0.0.1:8000"
data = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]
print("登录返回的字段：", list(data))

resp = requests.get(f"{BASE}/api/me", headers={"token": data["token"]}, timeout=10)
print("马上查：", resp.status_code, resp.json()["code"])

time.sleep(3)                                     # 等 token 过期
resp = requests.get(f"{BASE}/api/me", headers={"token": data["token"]}, timeout=10)
print("3 秒后再查：", resp.status_code, resp.json())

resp = requests.post(f"{BASE}/api/token/refresh", json={"refreshToken": data["refreshToken"]}, timeout=10)
new = resp.json()["data"]
print("刷新：", resp.status_code, "换来的 token 和原来的一样吗：", new["token"] == data["token"])
resp = requests.get(f"{BASE}/api/me", headers={"token": new["token"]}, timeout=10)
print("用新 token 查：", resp.status_code, resp.json()["code"])

resp = requests.post(f"{BASE}/api/token/refresh", json={"refreshToken": data["refreshToken"]}, timeout=10)
print("旧的 refreshToken 再用一次：", resp.status_code, resp.json())
