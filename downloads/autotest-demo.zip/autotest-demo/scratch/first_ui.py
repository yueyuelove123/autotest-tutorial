# 第一个 UI 脚本：打开浏览器登录，确认进入商品页，截一张图
from playwright.sync_api import expect, sync_playwright

with sync_playwright() as p:
    # channel="chrome" 用本机装的 Chrome；headless=False 能看到浏览器；slow_mo 让每步慢 500 毫秒，方便看清
    browser = p.chromium.launch(channel="chrome", headless=False, slow_mo=500)
    page = browser.new_page()
    page.goto("http://127.0.0.1:8000/login.html")
    page.get_by_label("用户名").fill("alice")
    page.get_by_label("密码").fill("alice123")
    page.get_by_role("button", name="登录").click()
    expect(page.get_by_test_id("welcome")).to_have_text("欢迎，alice")
    page.screenshot(path="first_ui.png")
    print("登录成功，截图保存在 first_ui.png")
    browser.close()
