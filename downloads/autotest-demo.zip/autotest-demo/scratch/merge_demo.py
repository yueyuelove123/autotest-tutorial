# 同一商品写成两行，看服务器怎么处理：合并成一行，还是扣两次库存
import requests

BASE = "http://127.0.0.1:8000"
login = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10)
headers = {"token": login.json()["data"]["token"]}


def stock():
    """中性笔（13 号商品）当前的库存。"""
    return requests.get(f"{BASE}/api/products/13", timeout=10).json()["data"]["stock"]


print("下单前库存：", stock())
items = [{"productId": 13, "quantity": 1}, {"productId": 13, "quantity": 1}]
resp = requests.post(f"{BASE}/api/orders", json={"items": items}, headers=headers, timeout=10)
order_no = resp.json()["data"]["orderNo"]
detail = requests.get(f"{BASE}/api/orders/{order_no}", headers=headers, timeout=10).json()["data"]
print("订单号：", order_no, "金额：", detail["amount"])
print("订单明细：", detail["items"])
print("下单后库存：", stock())
requests.post(f"{BASE}/api/orders/{order_no}/cancel", headers=headers, timeout=10)
print("取消后库存：", stock())
