"""用 Selenium 把练习网站走一遍：登录、搜索（显式等待）、下拉筛选、弹窗、iframe、新标签页。

运行前：练习网站在 8000 端口运行着；chromedriver.exe 放在 D:/tool/chromedriver/ 下（12.2 节）。
"""
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import Select, WebDriverWait

BASE = "http://127.0.0.1:8000"

driver = webdriver.Chrome(service=Service(r"D:\tool\chromedriver\chromedriver.exe"))
wait = WebDriverWait(driver, 10)            # 显式等待：最多等 10 秒，条件满足立刻往下走

# 1. 登录
driver.get(f"{BASE}/login.html")
driver.find_element(By.ID, "username").send_keys("alice")
driver.find_element(By.ID, "password").send_keys("alice123")
driver.find_element(By.CSS_SELECTOR, "button[type=submit]").click()
wait.until(ec.url_contains("/products.html"))
print("1 登录后的页面：", driver.current_url.rsplit("/", 1)[-1])

# 2. 搜索：点完按钮立刻数行数，和等列表刷新后再数，结果不一样
box = driver.find_element(By.ID, "keyword")
box.send_keys("耳机")
driver.find_element(By.CSS_SELECTOR, "#search-form button[type=submit]").click()
print("2 点完搜索立刻数：", len(driver.find_elements(By.CSS_SELECTOR, "#rows tr")), "行")
wait.until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "#rows tr")) == 2)
first = driver.find_elements(By.CSS_SELECTOR, "#rows tr")[0]
print("2 等列表刷新后再数：", len(driver.find_elements(By.CSS_SELECTOR, "#rows tr")), "行，第一行：", first.text.split(" ")[0])

# 3. 下拉框：Selenium 用 Select 类操作原生 select
driver.get(f"{BASE}/lab.html")
Select(driver.find_element(By.ID, "city")).select_by_visible_text("杭州")
print("3 下拉框选中：", Select(driver.find_element(By.ID, "city")).first_selected_option.text)

# 4. 浏览器弹窗：先等弹窗出现，再切过去点取消
driver.find_element(By.ID, "btn-confirm").click()
alert = wait.until(ec.alert_is_present())
print("4 弹窗文字：", alert.text)
alert.dismiss()
print("4 点取消后：", driver.find_element(By.ID, "result").text)

# 5. iframe：先切进去才能找里面的元素，用完切回来
driver.switch_to.frame("inner")
print("5 iframe 里的文字：", driver.find_element(By.CSS_SELECTOR, "[data-testid=from]").text)
driver.switch_to.default_content()

# 6. 新标签页：记住原窗口，等第二个窗口出现后切过去
main = driver.current_window_handle
driver.find_element(By.CSS_SELECTOR, "[data-testid=open-tab]").click()
wait.until(ec.number_of_windows_to_be(2))
driver.switch_to.window([h for h in driver.window_handles if h != main][0])
print("6 新标签页里的文字：", driver.find_element(By.CSS_SELECTOR, "[data-testid=from]").text)
driver.close()
driver.switch_to.window(main)

driver.quit()
