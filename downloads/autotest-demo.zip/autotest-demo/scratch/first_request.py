# 第一个接口请求：登录，然后用拿到的 token 查自己的余额
import requests

BASE = "http://127.0.0.1:8000"

resp = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10)
print("状态码：", resp.status_code)
print("响应体：", resp.json())

token = resp.json()["data"]["token"]
me = requests.get(f"{BASE}/api/me", headers={"token": token}, timeout=10)
print("我的信息：", me.json())
