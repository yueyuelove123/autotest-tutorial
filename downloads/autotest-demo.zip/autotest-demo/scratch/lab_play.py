# 第 10 章的操作练习脚本：把练习场上的交互挨个玩一遍，边跑边看打印
# 运行：(.venv) > python scratch\lab_play.py
from playwright.sync_api import sync_playwright, expect

with sync_playwright() as p:
    browser = p.chromium.launch(channel="chrome", headless=False, slow_mo=300)
    page = browser.new_page(base_url="http://127.0.0.1:8000")
    page.goto("/lab.html")

    # ---- 浏览器自带弹窗 ----
    page.once("dialog", lambda d: (print("弹窗类型：", d.type, "文字：", d.message), d.accept()))
    page.get_by_test_id("btn-alert").click()
    page.once("dialog", lambda d: d.accept())
    page.get_by_test_id("btn-confirm").click()
    print("confirm 点确定：", page.get_by_test_id("result").inner_text())
    page.once("dialog", lambda d: d.dismiss())
    page.get_by_test_id("btn-confirm").click()
    print("confirm 点取消：", page.get_by_test_id("result").inner_text())
    page.once("dialog", lambda d: d.accept("小麦"))
    page.get_by_test_id("btn-prompt").click()
    print("prompt 输入后确定：", page.get_by_test_id("result").inner_text())

    # ---- 悬停与双击 ----
    page.get_by_test_id("btn-hover").hover()
    expect(page.get_by_test_id("tip")).to_be_visible()
    print("悬停后提示：", page.get_by_test_id("tip").inner_text())
    page.get_by_test_id("btn-dblclick").dblclick()
    page.get_by_test_id("btn-dblclick").dblclick()
    print("双击两次计数：", page.get_by_test_id("dblcount").inner_text())

    # ---- 右键 ----
    page.get_by_test_id("canvas").click(button="right")
    print("右键结果：", page.get_by_test_id("context-result").inner_text())

    # ---- 鼠标拖动方块 ----
    box = page.get_by_test_id("box")
    bb = box.bounding_box()
    page.mouse.move(bb["x"] + 30, bb["y"] + 30)
    page.mouse.down()
    page.mouse.move(bb["x"] + 130, bb["y"] + 80, steps=5)
    page.mouse.up()
    print("拖动后落点：", page.get_by_test_id("pos").inner_text())

    # ---- 键盘：fill 与逐字符输入的差别 ----
    page.get_by_test_id("kbd").fill("hi")
    print("fill 之后 key-result：", repr(page.get_by_test_id("key-result").inner_text()))
    page.get_by_test_id("kbd").fill("")
    page.get_by_test_id("kbd").press_sequentially("hi", delay=100)
    print("逐字符输入后 key-result：", repr(page.get_by_test_id("key-result").inner_text()))
    page.get_by_test_id("kbd").press("Enter")
    print("按回车后 key-result：", repr(page.get_by_test_id("key-result").inner_text()))

    # ---- 下拉、复选、单选、日期，然后提交 ----
    page.get_by_label("城市").select_option(label="杭州")
    page.get_by_label("同意协议").check()
    page.get_by_label("微信").check()
    page.get_by_label("日期").fill("2026-10-22")
    page.get_by_test_id("btn-submit").click()
    print("提交结果：", page.get_by_test_id("form-result").inner_text())

    browser.close()
