"""手工试一下头像上传：先看没上传时的样子，再传一个 txt，最后传一张真正的 png。"""
import requests

BASE = "http://127.0.0.1:8000"
# 一张 1×1 像素的红色 PNG 图片，一共 69 个字节。四行依次是：文件头、尺寸信息、像素数据、结束标记
PNG = bytes.fromhex(
    "89504e470d0a1a0a"
    "0000000d4948445200000001000000010802000000907753de"
    "0000000c49444154789c63f8cfc0000003010100c9fe92ef"
    "0000000049454e44ae426082"
)

token = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]["token"]
headers = {"token": token}
print("没上传时看头像：", requests.get(f"{BASE}/api/users/avatar", headers=headers, timeout=10).json())

# files 的写法：{表单字段名: (文件名, 文件内容, 文件类型)}
resp = requests.post(f"{BASE}/api/users/avatar", files={"file": ("note.txt", b"hello", "text/plain")},
                     headers=headers, timeout=10)
print("传 txt：", resp.json())

resp = requests.post(f"{BASE}/api/users/avatar", files={"file": ("avatar.png", PNG, "image/png")},
                     headers=headers, timeout=10)
print("传 png：", resp.json())
print("上传后 hasAvatar：", requests.get(f"{BASE}/api/me", headers=headers, timeout=10).json()["data"]["hasAvatar"])
