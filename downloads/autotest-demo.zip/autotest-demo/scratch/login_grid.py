# 把登录的两个条件各取「空、对、错」三种值，九种组合挨个试一遍，看服务器返回什么业务码
import requests

BASE = "http://127.0.0.1:8000"
USERNAMES = {"空": "", "对": "bob", "错": "nobody"}
PASSWORDS = {"空": "", "对": "bob123", "错": "wrong-password"}

for u_name, username in USERNAMES.items():
    row = []
    for p_name, password in PASSWORDS.items():
        body = requests.post(f"{BASE}/api/login", json={"username": username, "password": password}, timeout=10).json()
        row.append(f"密码{p_name}→{body['code']}")
    print(f"用户名{u_name}：", "  ".join(row))
