"""同一份导出文件，用 utf-8 和 utf-8-sig 两种方式解码，看第一列的列名有什么不同。"""
import csv
import io

import requests

BASE = "http://127.0.0.1:8000"
token = requests.post(f"{BASE}/api/login", json={"username": "alice", "password": "alice123"}, timeout=10).json()["data"]["token"]
content = requests.get(f"{BASE}/api/orders/export", headers={"token": token}, timeout=10).content

for encoding in ("utf-8", "utf-8-sig"):
    header = next(csv.reader(io.StringIO(content.decode(encoding))))
    print(f"{encoding:9} 第一列的列名：{header[0]!r}，等于'订单号'吗：{header[0] == '订单号'}")
