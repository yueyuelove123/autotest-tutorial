"""越权探路：bob 建一个地址，alice 拿自己的 token 去查、改、删它。"""
import requests

BASE = "http://127.0.0.1:8000"


def login(username, password):
    token = requests.post(f"{BASE}/api/login", json={"username": username, "password": password}, timeout=10).json()["data"]["token"]
    return {"token": token}


alice = login("alice", "alice123")
bob = login("bob", "bob123")

addr = requests.post(f"{BASE}/api/addresses", headers=bob, timeout=10,
                     json={"receiver": "王小明", "phone": "13800001111", "detail": "人民路 1 号院 2 栋"}).json()["data"]
print("bob 的地址：", addr)

url = f"{BASE}/api/addresses/{addr['id']}"
print("alice 查：", requests.get(url, headers=alice, timeout=10).json())
print("alice 改：", requests.put(url, headers=alice, timeout=10,
                                json={"receiver": "李四", "phone": "13900002222", "detail": "幸福路 8 号 3 单元"}).json())
print("alice 删：", requests.delete(url, headers=alice, timeout=10).json())
print("bob 再看：", requests.get(url, headers=bob, timeout=10).json())
requests.delete(url, headers=bob, timeout=10)         # bob 收拾自己的数据
