"""不真的发出去，只看看 requests 把文件打包成了什么样子。"""
import requests

req = requests.Request(
    "POST", "http://127.0.0.1:8000/api/users/avatar",
    files={"file": ("avatar.png", b"(PNG-BYTES)", "image/png")},
).prepare()                      # prepare() 只组装请求，不发送

print("Content-Type:", req.headers["Content-Type"])
print("----- 请求体 -----")
print(req.body.decode())
