# autotest-demo：教程的参考代码

《从零开始学 UI 自动化、接口自动化与性能测试》学完全部章节后的最终版本。正文里会先写简单的版本再逐步改进，写到一半和这里不一样是正常的。

## 目录

```
autotest-demo/
├─ shop/                 练习网站（被测系统）：迷你商城，FastAPI 写的，数据都在内存里
├─ scratch/              入门练手的脚本：第一个接口脚本、第一个 UI 脚本、第 5 章的定位与等待示例
├─ common/               接口客户端（api_client.py）、读配置（config.py）
├─ config/               环境配置：local.yaml 是本机练习网站，staging.yaml.example 是样板
├─ data/                 测试数据：登录失败的数据、商品的结构约定
├─ pages/                UI 自动化的页面对象
├─ tests/
│  ├─ conftest.py        全局夹具：配置、账号、接口客户端、测试数据
│  ├─ api/               接口用例（28 条，含 1 条并发用例）
│  └─ ui/                UI 用例（10 条）和 UI 专用夹具
├─ perf/                 Locust 写的压测脚本：locustfile.py 是第 19 章流水线里的日常冒烟压测
├─ lr/                   LoadRunner 脚本：shop_order 是第 15 章整理好的压测脚本（登录、搜索、下单、支付），
│                        pay_race 是第 18 章并发支付实验的脚本（带造单脚本 make_order.py）
├─ tools/                notify.py 把测试结果发到企业微信群；lr_summary.py 汇总 LoadRunner 结果（第 17 章）；
│                        mem_watch.py 记录进程内存（第 18 章）；run_lr.ps1 运行场景并检查结果（第 19 章）
├─ .github/workflows/    流水线示例（没有在真实的流水线上跑过）
├─ allurerc.yaml         Allure 3 报告配置
├─ pytest.ini            pytest 配置
└─ requirements.txt      依赖清单
```

## 快速运行（Windows PowerShell）

```
# 1. 准备环境（只需要一次）
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# 2. 启动练习网站（单独开一个窗口，一直开着）
python -m uvicorn shop.app:app --port 8000 --no-access-log

# 3. 跑全部用例并生成报告（另开一个窗口，先激活虚拟环境）
pytest --alluredir=reports/allure-results --clean-alluredir
allure generate reports/allure-results          # 需要先装 Node.js 和 npm install -g allure

# 4. 并行跑
pytest -n 4

# 5. 日常压测（50 个用户 1 分钟，不达标时退出码为 1）
locust -f perf/locustfile.py --headless -u 50 -r 10 -t 1m --host http://127.0.0.1:8000 --html reports/perf/daily.html

# 6. LoadRunner：命令行运行一个场景并检查结果（场景在 Controller 里建好，见第 16 章）
powershell -NoProfile -ExecutionPolicy Bypass -File tools\run_lr.ps1 -Scenario D:\work\autotest-demo\lr\scenarios\demo16.lrs -ResultRoot D:\work\lr-results

# 7. 汇总一次 LoadRunner 的结果；阶梯加压时加 --step 60 --skip 15 按档汇总
python tools/lr_summary.py D:\work\lr-results\demo16
```

UI 用例默认用本机安装的 Chrome（`pytest.ini` 里的 `--browser-channel=chrome`）。没装 Chrome 的话改成 `msedge`，或者执行 `playwright install chromium` 后去掉这个参数。

## 练习网站的开关

启动练习网站前设置环境变量（PowerShell 写法 `$env:名字 = "值"`），改完要重启练习网站：

| 环境变量 | 默认 | 作用 |
|---|---|---|
| `SHOP_DB_POOL` | 8 | 模拟的数据库连接池大小，第 18 章调优对比用 |
| `SHOP_DB_LATENCY_MS` | 50 | 模拟一次数据库查询的耗时（毫秒） |
| `SHOP_PAY_RACE_BUG` | 不设置 | 设为 1 时支付接口带并发重复扣款的缺陷，第 18 章并发测试用 |
| `SHOP_SINGLE_SESSION` | 不设置 | 设为 1 时同一账号只认最后一次登录，第 18 章账号实验用 |
| `SHOP_INIT_BALANCE` | 100000 | 每个账号的初始余额（元），长时间压测前调大，第 18 章找拐点和稳定性测试用 |

环境变量一直有效到命令行窗口关闭。实验做完用 `Remove-Item Env:名字` 去掉（或者关掉窗口重开），再重启练习网站，否则后面的结果会受影响。

## 账号

| 账号 | 密码 | 用途 |
|---|---|---|
| alice | alice123 | 主账号 |
| bob | bob123 | 登录类用例专用 |
| user001～user100 | test123 | 账号池，并行执行和压测用 |
