"""错误示范：所有虚拟用户共用同一个账号（第 8 章 8.1.2）。

先用单会话模式启动练习网站（同一账号只认最后一次登录），再运行：
    locust -f perf/demo_one_account.py --headless -u 20 -r 20 -t 15s --host http://127.0.0.1:8000
"""
from locust import HttpUser, between, task


class OneAccountUser(HttpUser):
    wait_time = between(0.5, 1.5)

    def on_start(self):
        # 20 个虚拟用户都用 alice 登录，后登录的会把先登录的顶掉
        resp = self.client.post("/api/login", json={"username": "alice", "password": "alice123"}, name="/api/login")
        self.client.headers["token"] = resp.json()["data"]["token"]

    @task
    def my_orders(self):
        with self.client.get("/api/orders", name="/api/orders", catch_response=True) as resp:
            if resp.status_code != 200:
                resp.failure(f"HTTP {resp.status_code}")
