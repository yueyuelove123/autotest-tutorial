"""迷你商城的混合业务场景：搜索 60%、看详情 30%、下单并支付 10%。

这里只定义「一个用户会做什么」，跑多少人、跑多久由启动参数或 step_load.py 决定。
"""
import itertools
import random

from locust import HttpUser, between, task

KEYWORDS = ["耳机", "键盘", "杯", "包", "笔", "显示器", ""]
PRODUCT_IDS = range(1, 25)              # 1～24 号是库存充足的普通商品
_account_no = itertools.count(1)        # 账号池计数：第 1 个用户用 user001，第 2 个用 user002……


def next_account():
    n = next(_account_no)
    return f"user{(n - 1) % 100 + 1:03d}", "test123"     # 账号池只有 100 个，用完从头复用


def check(resp):
    """业务检查点：HTTP 200 且业务码为 0 才算成功，否则在统计里记一次失败。返回 data。"""
    try:
        body = resp.json()
    except ValueError:
        resp.failure(f"响应不是 JSON，HTTP {resp.status_code}")
        return None
    if resp.status_code != 200 or body.get("code") != 0:
        resp.failure(f"HTTP {resp.status_code}，code={body.get('code')}，{body.get('msg')}")
        return None
    return body["data"]


class ShopUser(HttpUser):
    wait_time = between(0.5, 1.5)

    def on_start(self):
        """每个虚拟用户启动时执行一次：从账号池取一个账号登录。"""
        username, password = next_account()
        with self.client.post("/api/login", json={"username": username, "password": password},
                              name="/api/login", catch_response=True) as resp:
            data = check(resp)
        if data:
            self.client.headers["token"] = data["token"]   # 之后这个用户的请求都带上 token

    @task(6)
    def search(self):
        params = {"keyword": random.choice(KEYWORDS), "size": 10}
        with self.client.get("/api/products", params=params, name="/api/products", catch_response=True) as resp:
            check(resp)

    @task(3)
    def detail(self):
        pid = random.choice(PRODUCT_IDS)
        # 地址里带商品编号，不写 name 的话每个编号会单独统计一行，报表就乱了
        with self.client.get(f"/api/products/{pid}", name="/api/products/[id]", catch_response=True) as resp:
            check(resp)

    @task(1)
    def buy(self):
        items = [{"productId": random.choice(PRODUCT_IDS), "quantity": 1}]
        with self.client.post("/api/orders", json={"items": items}, name="/api/orders", catch_response=True) as resp:
            order = check(resp)
        if not order:
            return
        with self.client.post(f"/api/orders/{order['orderNo']}/pay", name="/api/orders/[orderNo]/pay",
                              catch_response=True) as resp:
            check(resp)
