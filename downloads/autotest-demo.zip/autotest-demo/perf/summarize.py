"""把阶梯压测的 *_stats_history.csv 按用户数分档汇总，帮你找拐点。

用法：
    python perf/summarize.py reports/perf/step_stats_history.csv
输出一张 Markdown 表格，可以直接贴进测试报告。
"""
import csv
import statistics
import sys
from collections import defaultdict

SKIP_SECONDS = 10  # 每一档开头 10 秒用户还在启动，数据不稳，不算


def summarize(path):
    with open(path, encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if r["Name"] == "Aggregated"]
    first_seen, steps = {}, defaultdict(list)
    for r in rows:
        users, ts = int(r["User Count"]), int(r["Timestamp"])
        if users == 0 or r["95%"] == "N/A":
            continue
        first_seen.setdefault(users, ts)
        if ts - first_seen[users] >= SKIP_SECONDS:
            steps[users].append(r)

    print("| 用户数 | 每秒请求数 | P95 响应时间（毫秒） | 每秒失败数 | 说明 |")
    print("|---:|---:|---:|---:|---|")
    prev, found = None, False
    for users in sorted(steps):
        rs = steps[users]
        rps = statistics.median(float(r["Requests/s"]) for r in rs)
        p95 = statistics.median(float(r["95%"]) for r in rs)
        fails = statistics.median(float(r["Failures/s"]) for r in rs)
        note = ""
        # 用户多了，每秒请求数却几乎不涨，响应时间明显变长：说明系统处理不过来、请求在排队
        if not found and prev and rps < prev[0] * 1.05 and p95 > prev[1] * 1.5:
            note, found = "吞吐量不再增长、响应时间变长，拐点在这附近", True
        print(f"| {users} | {rps:.1f} | {p95:.0f} | {fails:.1f} | {note} |")
        prev = (rps, p95)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("用法：python perf/summarize.py <stats_history.csv 的路径>")
    summarize(sys.argv[1])
