"""阶梯加压：每隔一段时间加一批用户，用来找系统的拐点。

运行：
    locust -f perf/step_load.py --headless --host http://127.0.0.1:8000 --csv reports/perf/step
跑完用 summarize.py 按阶梯汇总：
    python perf/summarize.py reports/perf/step_stats_history.csv
"""
import os

from locust import LoadTestShape

from scenario import ShopUser  # noqa: F401


class StepLoad(LoadTestShape):
    step_users = int(os.getenv("STEP_USERS", "20"))       # 每一档加多少用户
    step_seconds = int(os.getenv("STEP_SECONDS", "30"))   # 每一档持续多少秒
    max_users = int(os.getenv("MAX_USERS", "200"))        # 加到多少为止

    def tick(self):
        """Locust 大约每秒调用一次，返回（目标用户数，每秒启动几个用户）；返回 None 表示结束。"""
        step = int(self.get_run_time() // self.step_seconds) + 1
        users = step * self.step_users
        if users > self.max_users:
            return None
        return users, self.step_users
