"""第一个压测脚本：一群用户反复搜索商品。

运行：locust -f perf/locustfile_basic.py --host http://127.0.0.1:8000
然后浏览器打开 http://localhost:8089
"""
from locust import HttpUser, between, task


class SearchUser(HttpUser):
    wait_time = between(1, 2)  # 每个用户做完一件事，停 1～2 秒再做下一件（模拟真人的思考时间）

    @task
    def search(self):
        self.client.get("/api/products", params={"keyword": "耳机"})
