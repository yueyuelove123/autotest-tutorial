"""日常压测入口：混合场景 + 结束时按性能指标判定是否达标。

运行（无界面，50 个用户，每秒启动 10 个，跑 1 分钟）：
    locust -f perf/locustfile.py --headless -u 50 -r 10 -t 1m --host http://127.0.0.1:8000 --csv reports/perf/daily --html reports/perf/daily.html
不达标时进程退出码为 1，流水线据此判定失败。
"""
import logging

from locust import events
from locust.runners import WorkerRunner

from scenario import ShopUser  # noqa: F401  导入后 Locust 会自动找到这个用户类

# 每个接口 95% 的请求要在多少毫秒内返回
P95_LIMIT_MS = {
    "/api/products": 300,
    "/api/products/[id]": 300,
    "/api/orders": 500,
    "/api/orders/[orderNo]/pay": 500,
}
MAX_FAIL_RATIO = 0.01  # 失败率不能超过 1%


@events.quitting.add_listener
def check_sla(environment, **kwargs):
    if isinstance(environment.runner, WorkerRunner):
        return  # 分布式压测时只在主控节点上判定
    stats = environment.stats
    problems = []
    if stats.total.num_requests == 0:
        problems.append("一个请求都没有发出去")
    if stats.total.fail_ratio > MAX_FAIL_RATIO:
        problems.append(f"失败率 {stats.total.fail_ratio:.2%}，超过 {MAX_FAIL_RATIO:.0%}")
    for (name, method), entry in stats.entries.items():
        limit = P95_LIMIT_MS.get(name)
        if limit and entry.num_requests:
            p95 = entry.get_response_time_percentile(0.95)
            if p95 > limit:
                problems.append(f"{method} {name} 的 P95 是 {p95:.0f} 毫秒，超过 {limit} 毫秒")
    if problems:
        for p in problems:
            logging.error("未达标：%s", p)
        environment.process_exit_code = 1
    else:
        logging.info("性能指标全部达标")
        environment.process_exit_code = 0
