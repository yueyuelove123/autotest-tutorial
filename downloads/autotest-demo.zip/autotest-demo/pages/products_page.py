"""商品列表页的页面对象。"""
from playwright.sync_api import Page


class ProductsPage:
    URL = "/products.html"

    def __init__(self, page: Page):
        self.page = page
        self.welcome = page.get_by_test_id("welcome")
        self.balance = page.get_by_test_id("balance")
        self.keyword = page.get_by_label("关键词")
        self.search_button = page.get_by_role("button", name="搜索")
        self.rows = page.get_by_test_id("product-row")
        self.state = page.locator("#state")
        self.dialog = page.get_by_role("dialog")
        self.toast = page.get_by_role("status")

    def open(self):
        self.page.goto(self.URL)
        return self

    def search(self, keyword: str):
        self.keyword.fill(keyword)
        self.search_button.click()

    def row(self, name: str):
        """名称里包含 name 的那一行商品。"""
        return self.rows.filter(has_text=name)

    def buy(self, name: str, quantity: int = 1):
        self.row(name).get_by_role("button", name="购买").click()
        self.dialog.get_by_label("数量").fill(str(quantity))
        self.dialog.get_by_role("button", name="确认下单").click()
