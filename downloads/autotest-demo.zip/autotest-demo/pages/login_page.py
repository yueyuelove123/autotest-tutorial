"""登录页的页面对象：页面上有什么元素、能做什么操作，都写在这里。"""
from playwright.sync_api import Page


class LoginPage:
    URL = "/login.html"

    def __init__(self, page: Page):
        self.page = page
        self.username = page.get_by_label("用户名")
        self.password = page.get_by_label("密码")
        self.submit = page.get_by_role("button", name="登录")
        self.error = page.get_by_role("alert")

    def open(self):
        self.page.goto(self.URL)
        return self

    def login(self, username: str, password: str):
        self.username.fill(username)
        self.password.fill(password)
        self.submit.click()
