"""我的订单页的页面对象。"""
from playwright.sync_api import Page


class OrdersPage:
    URL = "/orders.html"

    def __init__(self, page: Page):
        self.page = page
        self.balance = page.get_by_test_id("balance")
        self.status_filter = page.get_by_label("状态")
        self.rows = page.get_by_test_id("order-row")
        self.toast = page.get_by_role("status")

    def open(self):
        self.page.goto(self.URL)
        return self

    def filter_by_status(self, text: str):
        """按状态筛选，text 是下拉框里显示的文字，比如「已取消」。"""
        self.status_filter.select_option(label=text)

    def row(self, order_no: str):
        return self.rows.filter(has_text=order_no)

    def pay(self, order_no: str):
        self.row(order_no).get_by_role("button", name="支付").click()

    def cancel(self, order_no: str):
        # 取消前页面会弹出浏览器自带的确认框，先说好「出现了就点确定」，再去点按钮
        self.page.once("dialog", lambda dialog: dialog.accept())
        self.row(order_no).get_by_role("button", name="取消").click()
