// 几个页面共用的代码：读写 cookie、调接口、顶部栏、提示条

function getCookie(name) {
  const hit = document.cookie.split("; ").find((s) => s.startsWith(name + "="));
  return hit ? decodeURIComponent(hit.slice(name.length + 1)) : "";
}

function setCookie(name, value) {
  document.cookie = `${name}=${encodeURIComponent(value)}; path=/`;
}

function toLogin() {
  document.cookie = "token=; path=/; max-age=0";
  document.cookie = "username=; path=/; max-age=0";
  location.href = "/login.html";
}

// 需要登录的页面一打开就检查：token 和 username 两个 cookie 缺一个都当成没登录
function requireLogin() {
  if (!getCookie("token") || !getCookie("username")) {
    toLogin();
    return false;
  }
  return true;
}

// 调接口：自动带上 token 请求头；返回 {code, msg, data}
async function api(method, path, body) {
  const headers = { token: getCookie("token") };
  const options = { method, headers };
  if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const resp = await fetch(path, options);
  if (resp.status === 401) {
    toLogin();
    throw new Error("未登录");
  }
  try {
    return await resp.json();
  } catch (e) {
    throw new Error(`服务异常（HTTP ${resp.status}）`);
  }
}

async function refreshBalance() {
  const res = await api("GET", "/api/me");
  if (res.code === 0) {
    document.getElementById("balance").textContent = `余额：¥${res.data.balance.toFixed(2)}`;
  }
}

function renderHeader() {
  document.getElementById("welcome").textContent = `欢迎，${getCookie("username")}`;
  document.getElementById("logout").addEventListener("click", async () => {
    await api("POST", "/api/logout");
    toLogin();
  });
  refreshBalance();
}

// 页面底部的提示条，8 秒后自动消失
let toastTimer;
function toast(text, linkHref, linkText) {
  const el = document.getElementById("toast");
  el.replaceChildren(document.createTextNode(text));
  if (linkHref) {
    const a = document.createElement("a");
    a.href = linkHref;
    a.textContent = linkText;
    el.append(" ", a);
  }
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), 8000);
}

function cell(text) {
  const td = document.createElement("td");
  td.textContent = text;
  return td;
}

function button(text, onClick) {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = text;
  b.addEventListener("click", onClick);
  return b;
}
