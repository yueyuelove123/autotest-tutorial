"""迷你商城：教程配套的练习网站（被测系统）。

启动（在工程根目录执行）：
    python -m uvicorn shop.app:app --port 8000

浏览器打开 http://127.0.0.1:8000 是登录页，http://127.0.0.1:8000/docs 是接口文档。
数据都放在内存里，停掉服务再启动就回到初始状态。

下面几个环境变量是给教学用的开关，平时不用管：
    SHOP_DB_POOL         模拟的数据库连接池大小，默认 8（性能测试章找瓶颈用）
    SHOP_DB_LATENCY_MS   模拟一次数据库查询的耗时（毫秒），默认 50
    SHOP_PAY_RACE_BUG    设为 1 时，支付接口带一个并发重复扣款的缺陷
    SHOP_SINGLE_SESSION  设为 1 时，同一账号只认最后一次登录，之前的 token 全部失效
    SHOP_INIT_BALANCE    每个账号的初始余额（元），默认 100000，长时间压测前调大
    SHOP_TOKEN_TTL       token 有效期（秒），默认 0 表示永不过期（token 刷新一节用）
    SHOP_TASK_LATENCY    库存报表任务要跑多少秒，默认 3（异步任务一节用）
    SHOP_IDOR_BUG        设为 1 时，地址详情接口不校验归属，能看别人的地址（越权一节用）
"""
import contextlib
import csv
import hashlib
import io
import itertools
import os
import random
import re
import secrets
import threading
import time
from datetime import datetime
from pathlib import Path

from fastapi import Depends, FastAPI, File, Query, Security, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse, Response
from fastapi.security import APIKeyHeader
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DB_POOL = int(os.getenv("SHOP_DB_POOL", "8"))
DB_LATENCY_MS = int(os.getenv("SHOP_DB_LATENCY_MS", "50"))
PAY_RACE_BUG = os.getenv("SHOP_PAY_RACE_BUG") == "1"
SINGLE_SESSION = os.getenv("SHOP_SINGLE_SESSION") == "1"
INIT_BALANCE = int(os.getenv("SHOP_INIT_BALANCE", "100000"))
TOKEN_TTL = int(os.getenv("SHOP_TOKEN_TTL", "0"))          # 0 表示永不过期
TASK_LATENCY = float(os.getenv("SHOP_TASK_LATENCY", "3"))
IDOR_BUG = os.getenv("SHOP_IDOR_BUG") == "1"
# 开放接口的签名密钥：签名 = md5(密钥 + 时间戳)，见 /api/stats 接口（接口签名一节用）
OPEN_API_SECRET = os.getenv("SHOP_OPEN_SECRET", "shop-secret-2026")

app = FastAPI(
    title="迷你商城",
    description="教程配套的练习网站。需要登录的接口：先调登录接口拿到 token，再点右上角 Authorize 填进去。",
)

# ---------------------------------------------------------------- 初始数据

_PRODUCTS = [  # (名称, 单价)
    ("蓝牙耳机", 199.00), ("头戴式耳机", 399.00), ("机械键盘", 299.00), ("无线鼠标", 89.00),
    ("显示器", 1299.00), ("显示器支架", 159.00), ("USB-C 数据线", 29.90), ("充电宝", 129.00),
    ("保温杯", 79.00), ("马克杯", 35.00), ("双肩包", 199.00), ("斜挎包", 149.00),
    ("中性笔", 2.50), ("笔记本", 12.80), ("台灯", 99.00), ("收纳盒", 25.00),
    ("雨伞", 49.00), ("毛巾", 19.90), ("运动水壶", 39.00), ("瑜伽垫", 89.00),
    ("跳绳", 25.00), ("哑铃", 159.00), ("篮球", 129.00), ("T恤", 59.00),
    ("限量版手办", 599.00),
]
LIMITED_STOCK = {"限量版手办": 3}       # 这件只有 3 个库存，练「库存不足」用
# 金额一律按「分」存整数，避免小数计算的误差；接口返回时再换算成元
PRODUCTS = {
    i: {"id": i, "sku": f"SKU{i:04d}", "name": name, "price": round(price * 100),
        "stock": LIMITED_STOCK.get(name, 100000)}
    for i, (name, price) in enumerate(_PRODUCTS, start=1)
}

_ACCOUNTS = {"alice": "alice123", "bob": "bob123"}
_ACCOUNTS.update({f"user{i:03d}": "test123" for i in range(1, 101)})  # 账号池 user001～user100
USERS = {
    name: {"password": pwd, "balance": INIT_BALANCE * 100, "nickname": name, "email": f"{name}@example.com"}
    for name, pwd in _ACCOUNTS.items()
}

TOKENS = {}                      # token -> (用户名, 登录时间)；登录时间为 0 表示永不过期
ORDERS = {}                      # 订单号 -> 订单
USER_ORDERS = {name: [] for name in USERS}   # 用户名 -> 订单号列表
STATUS_TEXT = {"UNPAID": "待支付", "PAID": "已支付", "CANCELLED": "已取消"}
ADDRESSES = {}                   # 地址编号 -> 地址；每个用户名下一个列表
_address_seq = itertools.count(1)
AVATARS = {}                     # 用户名 -> (文件类型, 图片字节)，上传的头像放内存里
REFRESH_TOKENS = {}              # 刷新 token -> 用户名
TASKS = {}                       # 任务编号 -> 任务（库存报表，异步任务一节用）
_task_seq = itertools.count(1)

_data_lock = threading.Lock()                               # 保护库存、订单、token
_user_locks = {name: threading.Lock() for name in USERS}    # 同一用户的支付、取消排队处理
_order_seq = itertools.count(1)
_db_pool = threading.BoundedSemaphore(DB_POOL)


def db_query():
    """模拟一次数据库查询：先拿到连接（连接池用完了就排队等），再花一点时间。"""
    with _db_pool:
        time.sleep(DB_LATENCY_MS / 1000 * random.uniform(0.6, 1.4))


def yuan(cents: int) -> float:
    return round(cents / 100, 2)


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- 统一返回格式

class NotLoggedIn(Exception):
    """token 无效（没登录）。HTTP 401，业务码 40101。"""

    pass


class TokenExpired(Exception):
    """登录已过期。HTTP 401，业务码 40102，客户端拿刷新 token 换新的。"""

    pass


def ok(data=None):
    return {"code": 0, "msg": "ok", "data": data}


def fail(code: int, msg: str, status: int = 200):
    """业务错误：HTTP 状态码默认还是 200，靠 code 区分（很多系统都这么做）。"""
    return JSONResponse({"code": code, "msg": msg, "data": None}, status_code=status)


@app.exception_handler(NotLoggedIn)
async def _on_not_logged_in(request, exc):
    return JSONResponse({"code": 40101, "msg": "未登录或 token 无效", "data": None}, status_code=401)


@app.exception_handler(TokenExpired)
async def _on_token_expired(request, exc):
    return JSONResponse({"code": 40102, "msg": "登录已过期", "data": None}, status_code=401)


@app.exception_handler(RequestValidationError)
async def _on_validation_error(request, exc):
    details = [
        {"field": ".".join(str(p) for p in err["loc"][1:]), "reason": err["msg"]}
        for err in exc.errors()
    ]
    return JSONResponse({"code": 422, "msg": "参数错误", "data": details}, status_code=422)


_token_header = APIKeyHeader(name="token", auto_error=False, description="登录接口返回的 token")


def login_user(token: str | None = Security(_token_header)) -> str:
    hit = TOKENS.get(token or "")
    if not hit:
        raise NotLoggedIn()
    username, logged_at = hit
    if TOKEN_TTL and logged_at and time.time() - logged_at > TOKEN_TTL:
        raise TokenExpired()                    # 过期的 token 每次来都报过期（和 JWT 一样），客户端拿刷新 token 换新的
    return username


def _download_user(
    token_header: str | None = Security(_token_header),
    token_query: str | None = Query(None, alias="token"),
) -> str:
    """下载接口用的校验：浏览器直接打开下载链接带不上请求头，允许 token 走查询参数。"""
    token = token_header or ""
    if token_query and not token_header:
        token = token_query
    return login_user(token)


# ---------------------------------------------------------------- 账号

class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/login", tags=["账号"], summary="登录")
def login(body: LoginIn):
    if not body.username or not body.password:
        return fail(1002, "用户名和密码不能为空")
    db_query()
    user = USERS.get(body.username)
    if not user or user["password"] != body.password:
        return fail(1001, "用户名或密码错误")      # 不区分「账号不存在」和「密码错」，防止被人试出账号
    token = secrets.token_hex(16)
    refresh = secrets.token_hex(16)               # 用来续期：token 过期后拿它换一对新的
    with _data_lock:
        if SINGLE_SESSION:
            for old in [t for t, (name, _) in TOKENS.items() if name == body.username]:
                del TOKENS[old]
        TOKENS[token] = (body.username, time.time() if TOKEN_TTL else 0)
        REFRESH_TOKENS[refresh] = body.username
    return ok({"token": token, "refreshToken": refresh, "username": body.username})


class RefreshIn(BaseModel):
    refreshToken: str


@app.post("/api/token/refresh", tags=["账号"], summary="用刷新 token 换一对新的 token（旧的立即作废）")
def refresh_token(body: RefreshIn):
    username = REFRESH_TOKENS.pop(body.refreshToken, None)    # 一次性：用掉就作废，防止被重放
    if not username:
        return fail(40103, "刷新 token 无效", status=401)
    token, refresh = secrets.token_hex(16), secrets.token_hex(16)
    with _data_lock:
        TOKENS[token] = (username, time.time() if TOKEN_TTL else 0)
        REFRESH_TOKENS[refresh] = username
    return ok({"token": token, "refreshToken": refresh, "username": username})


@app.post("/api/logout", tags=["账号"], summary="退出登录")
def logout(token: str | None = Security(_token_header), username: str = Depends(login_user)):
    with _data_lock:
        TOKENS.pop(token, None)
    return ok()


@app.get("/api/me", tags=["账号"], summary="当前用户信息")
def me(username: str = Depends(login_user)):
    user = USERS[username]
    return ok({
        "username": username, "nickname": user["nickname"],
        "email": user["email"], "balance": yuan(user["balance"]),
        "hasAvatar": username in AVATARS,
    })


class ProfileIn(BaseModel):
    nickname: str = Field(min_length=2, max_length=20, description="昵称，2～20 个字")


@app.put("/api/users/me", tags=["账号"], summary="修改昵称")
def update_profile(body: ProfileIn, username: str = Depends(login_user)):
    USERS[username]["nickname"] = body.nickname.strip()
    return ok({"username": username, "nickname": USERS[username]["nickname"]})


@app.post("/api/users/avatar", tags=["账号"], summary="上传头像（jpg 或 png，不超过 200 KB）")
async def upload_avatar(file: UploadFile = File(...), username: str = Depends(login_user)):
    if (file.content_type or "") not in ("image/jpeg", "image/png"):
        return fail(4001, "头像只支持 jpg 或 png 格式")
    data = await file.read()
    if len(data) > 200 * 1024:
        return fail(4002, "头像不能超过 200 KB")
    AVATARS[username] = (file.content_type, data)
    return ok({"size": len(data), "type": file.content_type})


@app.get("/api/users/avatar", tags=["账号"], summary="查看自己的头像（没上传过返回 4003）")
def get_avatar(
    token: str | None = Query(None, description="img 标签带不上请求头，可以从这里传 token"),
    username: str = Depends(_download_user),
):
    hit = AVATARS.get(username)
    if not hit:
        return fail(4003, "还没有上传过头像")
    ctype, data = hit
    return Response(content=data, media_type=ctype)


# ---------------------------------------------------------------- 商品

def product_view(p):
    return {"id": p["id"], "sku": p["sku"], "name": p["name"], "price": yuan(p["price"]), "stock": p["stock"]}


@app.get("/api/products", tags=["商品"], summary="搜索商品")
def search_products(
    keyword: str = Query("", description="按名称或编号模糊搜索，不填返回全部"),
    page: int = Query(1, ge=1, description="页码，从 1 开始"),
    size: int = Query(10, ge=1, le=50, description="每页条数，1～50"),
):
    db_query()
    kw = keyword.strip().lower()
    hits = [p for p in PRODUCTS.values() if kw in p["name"].lower() or kw in p["sku"].lower()]
    start = (page - 1) * size
    return ok({
        "total": len(hits), "page": page, "size": size,
        "items": [product_view(p) for p in hits[start:start + size]],
    })


@app.get("/api/products/{product_id}", tags=["商品"], summary="商品详情")
def get_product(product_id: int):
    db_query()
    p = PRODUCTS.get(product_id)
    if not p:
        return fail(2001, "商品不存在")
    return ok(product_view(p))


# ---------------------------------------------------------------- 订单

class OrderItemIn(BaseModel):
    productId: int
    quantity: int = Field(ge=1, le=999, description="购买数量，1～999")


class OrderIn(BaseModel):
    items: list[OrderItemIn] = Field(min_length=1, max_length=20)


def order_view(o):
    return {
        "orderNo": o["orderNo"],
        "status": o["status"],
        "statusText": STATUS_TEXT[o["status"]],
        "amount": yuan(o["amount"]),
        "items": [
            {"productId": it["productId"], "name": it["name"], "price": yuan(it["price"]), "quantity": it["quantity"]}
            for it in o["items"]
        ],
        "createdAt": o["createdAt"],
        "paidAt": o["paidAt"],
    }


def find_order(order_no: str, username: str):
    o = ORDERS.get(order_no)
    return o if o and o["username"] == username else None     # 别人的订单也当成不存在


@app.post("/api/orders", tags=["订单"], summary="下单（同时占用库存）")
def create_order(body: OrderIn, username: str = Depends(login_user)):
    wanted = {}
    for it in body.items:                     # 同一商品出现多次时合并数量
        wanted[it.productId] = wanted.get(it.productId, 0) + it.quantity
    db_query()
    with _data_lock:
        for pid, qty in wanted.items():
            p = PRODUCTS.get(pid)
            if not p:
                return fail(2001, f"商品不存在：{pid}")
            if p["stock"] < qty:
                return fail(2002, f"库存不足：{p['name']} 只剩 {p['stock']} 件")
        items = []
        for pid, qty in wanted.items():
            p = PRODUCTS[pid]
            p["stock"] -= qty
            items.append({"productId": pid, "name": p["name"], "price": p["price"], "quantity": qty})
        order_no = f"SO{datetime.now():%Y%m%d}{next(_order_seq):06d}"
        amount = sum(it["price"] * it["quantity"] for it in items)
        ORDERS[order_no] = {
            "orderNo": order_no, "username": username, "items": items, "amount": amount,
            "status": "UNPAID", "createdAt": now(), "paidAt": None,
        }
        USER_ORDERS[username].append(order_no)
    return ok({"orderNo": order_no, "amount": yuan(amount), "status": "UNPAID"})


@app.get("/api/orders", tags=["订单"], summary="我的订单（最近 50 条）")
def list_orders(
    status: str | None = Query(None, description="按状态筛选：UNPAID / PAID / CANCELLED"),
    username: str = Depends(login_user),
):
    db_query()
    orders = [ORDERS[no] for no in reversed(USER_ORDERS[username])]
    if status:
        orders = [o for o in orders if o["status"] == status]
    return ok({"total": len(orders), "items": [order_view(o) for o in orders[:50]]})


@app.get("/api/orders/export", tags=["订单"], summary="导出我的订单（CSV 文件，浏览器会下载）")
def export_orders(
    token: str | None = Query(None, description="浏览器直接打开下载链接时带不上请求头，可以从这里传 token"),
    username: str = Depends(_download_user),
):
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["订单号", "商品", "金额(元)", "状态", "下单时间"])
    with _data_lock:
        orders = [ORDERS[no] for no in reversed(USER_ORDERS[username])]
    for o in orders:
        goods = "，".join(f"{it['name']} ×{it['quantity']}" for it in o["items"])
        writer.writerow([o["orderNo"], goods, yuan(o["amount"]), STATUS_TEXT[o["status"]], o["createdAt"]])
    data = buf.getvalue().encode("utf-8-sig")     # 带上 BOM，用 Excel 打开不乱码
    return Response(
        data, media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=orders.csv"},
    )


@app.get("/api/orders/{order_no}", tags=["订单"], summary="订单详情")
def get_order(order_no: str, username: str = Depends(login_user)):
    db_query()
    o = find_order(order_no, username)
    if not o:
        return fail(3001, "订单不存在")
    return ok(order_view(o))


@app.post("/api/orders/{order_no}/pay", tags=["订单"], summary="支付订单（从余额扣款）")
def pay_order(order_no: str, username: str = Depends(login_user)):
    # 正常情况下同一用户的支付排队处理；打开缺陷开关后不排队，并发支付会重复扣款
    guard = contextlib.nullcontext() if PAY_RACE_BUG else _user_locks[username]
    with guard:
        o = find_order(order_no, username)
        if not o:
            return fail(3001, "订单不存在")
        if o["status"] != "UNPAID":
            return fail(3003, f"订单{STATUS_TEXT[o['status']]}，不能支付")
        user = USERS[username]
        if user["balance"] < o["amount"]:
            return fail(3002, "余额不足")
        db_query()                                   # 模拟调用支付通道、写支付流水
        user["balance"] -= o["amount"]
        o["status"] = "PAID"
        o["paidAt"] = now()
        return ok({"orderNo": order_no, "status": "PAID", "balance": yuan(user["balance"])})


@app.post("/api/orders/{order_no}/cancel", tags=["订单"], summary="取消订单（归还库存）")
def cancel_order(order_no: str, username: str = Depends(login_user)):
    with _user_locks[username]:
        o = find_order(order_no, username)
        if not o:
            return fail(3001, "订单不存在")
        if o["status"] != "UNPAID":
            return fail(3003, f"订单{STATUS_TEXT[o['status']]}，不能取消")
        db_query()
        with _data_lock:
            for it in o["items"]:
                PRODUCTS[it["productId"]]["stock"] += it["quantity"]
            o["status"] = "CANCELLED"
    return ok({"orderNo": order_no, "status": "CANCELLED"})


# ---------------------------------------------------------------- 收货地址（越权测试一节用）

class AddressIn(BaseModel):
    receiver: str = Field(min_length=2, max_length=20, description="收货人姓名，2～20 个字")
    phone: str = Field(description="11 位手机号，1 开头")
    detail: str = Field(min_length=5, max_length=100, description="详细地址，5～100 个字")


def address_view(a):
    return {"id": a["id"], "receiver": a["receiver"], "phone": a["phone"], "detail": a["detail"]}


def check_phone(phone: str) -> bool:
    return bool(re.fullmatch(r"1\d{10}", phone.strip()))


@app.post("/api/addresses", tags=["收货地址"], summary="新增收货地址")
def create_address(body: AddressIn, username: str = Depends(login_user)):
    if not check_phone(body.phone):
        return fail(5002, "手机号格式不对，要 1 开头的 11 位数字")
    addr = {"id": next(_address_seq), "owner": username,
            "receiver": body.receiver.strip(), "phone": body.phone.strip(), "detail": body.detail.strip()}
    ADDRESSES[addr["id"]] = addr
    return ok(address_view(addr))


@app.get("/api/addresses", tags=["收货地址"], summary="我的收货地址列表")
def list_addresses(username: str = Depends(login_user)):
    db_query()
    mine = [address_view(a) for a in ADDRESSES.values() if a["owner"] == username]
    return ok({"total": len(mine), "items": mine})


@app.get("/api/addresses/{address_id}", tags=["收货地址"], summary="地址详情（只查自己的；开越权开关后谁都能查）")
def get_address(address_id: int, username: str = Depends(login_user)):
    a = ADDRESSES.get(address_id)
    if not a or (a["owner"] != username and not IDOR_BUG):
        return fail(5001, "地址不存在")           # 别人的地址当成不存在，不提示「无权限」，防止猜编号
    return ok(address_view(a))


@app.put("/api/addresses/{address_id}", tags=["收货地址"], summary="修改收货地址（只改自己的；开越权开关后能改别人的）")
def update_address(address_id: int, body: AddressIn, username: str = Depends(login_user)):
    a = ADDRESSES.get(address_id)
    if not a or (a["owner"] != username and not IDOR_BUG):
        return fail(5001, "地址不存在")
    if not check_phone(body.phone):
        return fail(5002, "手机号格式不对，要 1 开头的 11 位数字")
    a["receiver"], a["phone"], a["detail"] = body.receiver.strip(), body.phone.strip(), body.detail.strip()
    return ok(address_view(a))


@app.delete("/api/addresses/{address_id}", tags=["收货地址"], summary="删除收货地址（只删自己的，这个接口不受越权开关影响）")
def delete_address(address_id: int, username: str = Depends(login_user)):
    a = ADDRESSES.get(address_id)
    if not a or a["owner"] != username:
        return fail(5001, "地址不存在")
    del ADDRESSES[address_id]
    return ok()


# ---------------------------------------------------------------- 开放接口（接口签名一节用）

@app.get("/api/stats/orders", tags=["开放接口"], summary="订单统计（开放给合作方的接口，要验签）")
def order_stats(
    x_app_key: str | None = Query(None, description="合作方身份，固定填 shop-open"),
    x_timestamp: str | None = Query(None, description="当前时间戳（秒），允许与服务器相差 300 秒内"),
    x_sign: str | None = Query(None, description="签名：md5(密钥 + 时间戳)，密钥向平台申请，演示环境是 shop-secret-2026"),
):
    """模拟开放平台的签名校验：错 appKey、过期时间戳、错签名都进不来，防重放。"""
    if x_app_key != "shop-open":
        return fail(4011, "appKey 不正确", status=401)
    try:
        ts = int(x_timestamp or "")
    except ValueError:
        return fail(4012, "时间戳格式不对", status=401)
    if abs(time.time() - ts) > 300:
        return fail(4013, "时间戳超出允许范围，请校准后重试", status=401)
    expect = hashlib.md5(f"{OPEN_API_SECRET}{ts}".encode()).hexdigest()
    if (x_sign or "").lower() != expect:
        return fail(4014, "签名不正确", status=401)
    with _data_lock:
        orders = list(ORDERS.values())
    paid = [o for o in orders if o["status"] == "PAID"]
    return ok({
        "totalOrders": len(orders), "paidOrders": len(paid),
        "totalAmount": yuan(sum(o["amount"] for o in paid)), "users": len(USERS),
    })


# ---------------------------------------------------------------- 异步任务（库存报表）

def _run_stock_report(task_id: str):
    """后台线程：模拟报表要算一会儿，算完把 CSV 放进任务里。"""
    time.sleep(TASK_LATENCY)
    db_query()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["商品编号", "商品名称", "单价(元)", "库存(件)"])
    with _data_lock:
        rows = [(p["sku"], p["name"], yuan(p["price"]), p["stock"]) for p in PRODUCTS.values()]
    writer.writerows(rows)
    TASKS[task_id]["csv"] = buf.getvalue().encode("utf-8-sig")
    TASKS[task_id]["status"] = "completed"
    TASKS[task_id]["finishedAt"] = now()


@app.post("/api/reports/stock", tags=["库存报表"], summary="提交库存报表任务（异步，要轮询结果）")
def create_stock_report(username: str = Depends(login_user)):
    task_id = f"TASK{next(_task_seq):06d}"
    TASKS[task_id] = {
        "id": task_id, "type": "stock", "status": "processing", "owner": username,
        "createdAt": now(), "finishedAt": None, "csv": None,
    }
    threading.Thread(target=_run_stock_report, args=(task_id,), daemon=True).start()
    return ok({"taskId": task_id, "status": "processing"})


@app.get("/api/tasks/{task_id}", tags=["库存报表"], summary="查任务状态（processing 是在跑，completed 是跑完了）")
def get_task(task_id: str, username: str = Depends(login_user)):
    t = TASKS.get(task_id)
    if not t or t["owner"] != username:
        return fail(6001, "任务不存在")
    return ok({k: t[k] for k in ("id", "type", "status", "createdAt", "finishedAt")})


@app.get("/api/tasks/{task_id}/download", tags=["库存报表"], summary="下载任务结果（任务没跑完返回 6002）")
def download_task_result(
    task_id: str,
    token: str | None = Query(None, description="同订单导出：浏览器直接打开时从这里传 token"),
    username: str = Depends(_download_user),
):
    t = TASKS.get(task_id)
    if not t or t["owner"] != username:
        return fail(6001, "任务不存在")
    if t["status"] != "completed":
        return fail(6002, "任务还没跑完，稍后再来下载")
    return Response(
        t["csv"], media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={task_id}.csv"},
    )


# ---------------------------------------------------------------- 其他

@app.get("/api/health", tags=["其他"], summary="健康检查")
def health():
    return ok({"status": "UP"})


@app.get("/", include_in_schema=False)
def index():
    return RedirectResponse("/login.html")


# 页面文件放在 static 目录，要写在所有接口后面，否则会把接口地址也当成文件去找
app.mount("/", StaticFiles(directory=Path(__file__).parent / "static"), name="static")
