Action()
{
	// �ؼ������� keyword.dat�������ģ���ת�� UTF-8�������ٷֺű��룬���ܷŽ���ַ
	lr_convert_string_encoding(lr_eval_string("{keyword}"), LR_ENC_SYSTEM_LOCALE, LR_ENC_UTF8, "kw_utf8");
	lr_save_string(lr_eval_string("{kw_utf8}"), "kw");
	web_convert_param("kw", "SourceEncoding=PLAIN", "TargetEncoding=URL", LAST);

	lr_start_transaction("02_search");

	web_reg_find("Text=\"code\":0", LAST);
	web_reg_save_param_json("ParamName=pid",
		"QueryString=$.data.items[0].id",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_url("search",
		"URL={base}/api/products?keyword={kw}&page=1&size=10",
		LAST);

	lr_end_transaction("02_search", LR_AUTO);

	lr_think_time(1);

	lr_start_transaction("03_order");

	web_reg_find("Text=\"code\":0", LAST);
	web_reg_save_param_json("ParamName=orderNo",
		"QueryString=$.data.orderNo",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_custom_request("order",
		"URL={base}/api/orders",
		"Method=POST",
		"EncType=application/json",
		"Body={\"items\":[{\"productId\":{pid},\"quantity\":1}]}",
		LAST);

	lr_end_transaction("03_order", LR_AUTO);

	lr_think_time(1);

	lr_start_transaction("04_pay");

	web_reg_save_param_json("ParamName=payCode",
		"QueryString=$.code",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_custom_request("pay",
		"URL={base}/api/orders/{orderNo}/pay",
		"Method=POST",
		LAST);

	// ֧��ʧ��ʱ HTTP ״̬������ 200��Ҫ��ҵ����
	if (strcmp(lr_eval_string("{payCode}"), "0") != 0) {
		lr_error_message("֧��ʧ�ܣ����� %s��ҵ���� %s", lr_eval_string("{orderNo}"), lr_eval_string("{payCode}"));
		lr_end_transaction("04_pay", LR_FAIL);
	} else {
		lr_end_transaction("04_pay", LR_AUTO);
	}

	lr_think_time(1);

	return 0;
}
