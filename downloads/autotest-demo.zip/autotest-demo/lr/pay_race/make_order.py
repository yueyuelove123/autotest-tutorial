r"""并发支付实验（第 18 章）的准备和检查：用 alice 下一张待支付订单，订单号写进 order.dat。

在工程根目录运行：
    python lr\pay_race\make_order.py          下单，打印订单号、金额和当前余额
    python lr\pay_race\make_order.py check    查 order.dat 里那张订单的状态和 alice 的余额
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))           # 让下面能导入工程里的 common 包

from common.api_client import ShopApi, ok  # noqa: E402

ORDER_FILE = Path(__file__).with_name("order.dat")
api = ShopApi("http://127.0.0.1:8000")
ok(api.login("alice", "alice123"))

if len(sys.argv) > 1 and sys.argv[1] == "check":
    order_no = ORDER_FILE.read_text(encoding="gbk").split()[1]
    order = ok(api.get_order(order_no))
    print(f"订单 {order_no}：状态 {order['status']}，金额 {order['amount']} 元")
    print(f"alice 当前余额：{ok(api.me())['balance']} 元")
else:
    product = ok(api.search_products("充电宝"))["items"][0]
    order = ok(api.create_order([{"productId": product["id"], "quantity": 1}]))
    # LoadRunner 的数据文件第一行是列名，第二行起是数据；用 GBK 存，和脚本的其他文件一致
    ORDER_FILE.write_text(f"orderNo\r\n{order['orderNo']}\r\n", encoding="gbk", newline="")
    print(f"已下单：{order['orderNo']}，金额 {order['amount']} 元，订单号已写进 {ORDER_FILE.name}")
    print(f"alice 当前余额：{ok(api.me())['balance']} 元")
