"""读取测试配置。

配置文件放在 config/<环境名>.yaml，环境名取环境变量 TEST_ENV，没设置就用 local。
文件里可以写 ${变量名}，读取时换成同名环境变量的值，口令这类敏感信息就不用写进文件。
"""
import os
import re
from functools import cache
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
_VAR = re.compile(r"\$\{(\w+)\}")


def _fill_env(text: str) -> str:
    def replace(match):
        name = match.group(1)
        if name not in os.environ:
            raise RuntimeError(f"配置里用到了环境变量 {name}，但它没有设置")
        return os.environ[name]

    return _VAR.sub(replace, text)


@cache
def load_config(env: str | None = None) -> dict:
    env = env or os.getenv("TEST_ENV", "local")
    path = ROOT / "config" / f"{env}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"找不到配置文件 {path}，检查 TEST_ENV={env} 写对没有")
    cfg = yaml.safe_load(_fill_env(path.read_text(encoding="utf-8")))
    cfg["env"] = env
    return cfg
