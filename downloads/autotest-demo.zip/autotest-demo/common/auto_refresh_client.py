"""带 token 自动续期的接口客户端。

业务请求收到 401、业务码 40102（登录过期）时，自动用 refreshToken 换一对新 token，
再把刚才那个请求重发一次，调用方不用关心续期这件事；refreshToken 也失效时抛出
SessionExpired，让用例失败并提示需要重新登录。

用法（和 ShopApi 一样）：
    api = AutoRefreshApi(base_url)
    api.login("alice", "alice123")
    api.me()          # 就算 token 刚好过期，这里也会自动续期后正常返回
"""
import threading

import requests

from common.api_client import ShopApi


class SessionExpired(Exception):
    """刷新 token 也失效了，只能重新用账号密码登录。"""


class AutoRefreshApi(ShopApi):
    """在 ShopApi 的基础上，给每个请求加上「过期自动续期并重发」。

    续期时要注意并发：refreshToken 是一次性的，两个请求同时发现过期、同时去刷新，
    后到的那个会拿到 40103。这里用一把锁保证同一时刻只有一个线程在刷新，
    其他线程等它刷完，直接用新 token 重发。
    """

    def __init__(self, base_url: str, timeout: float = 10):
        super().__init__(base_url, timeout)
        self.refresh_token = None
        self._refresh_lock = threading.Lock()

    def login(self, username, password):
        resp = super().login(username, password)
        if resp.status_code == 200 and resp.json()["code"] == 0:
            self.refresh_token = resp.json()["data"]["refreshToken"]
        return resp

    def request(self, method: str, path: str, **kwargs) -> requests.Response:
        resp = super().request(method, path, **kwargs)
        if not self._is_expired(resp):
            return resp
        with self._refresh_lock:
            used = resp.request.headers.get("token")
            if self.token == used:            # 别的线程还没刷新过，由这个线程来刷
                self._refresh()
        return super().request(method, path, **kwargs)   # 用新 token 重发一次

    @staticmethod
    def _is_expired(resp: requests.Response) -> bool:
        if resp.status_code != 401:
            return False
        try:
            return resp.json()["code"] == 40102
        except ValueError:
            return False

    def _refresh(self):
        resp = self.session.post(
            f"{self.base_url}/api/token/refresh",
            json={"refreshToken": self.refresh_token},
            timeout=self.timeout,
        )
        body = resp.json()
        if body["code"] != 0:
            raise SessionExpired(f"续期失败（{body['code']} {body['msg']}），请重新登录")
        self.session.headers["token"] = body["data"]["token"]
        self.refresh_token = body["data"]["refreshToken"]
