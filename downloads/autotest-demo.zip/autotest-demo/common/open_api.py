"""开放接口的客户端：每个请求自动带上 appKey、时间戳和签名。"""
import hashlib
import time

from common.api_client import ApiClient


def make_sign(secret: str, timestamp: int) -> str:
    """按平台规则算签名：md5(密钥 + 时间戳)，结果是 32 位小写的十六进制字符串。"""
    return hashlib.md5(f"{secret}{timestamp}".encode("utf-8")).hexdigest()


class OpenApi(ApiClient):
    """开放接口不用登录，靠签名证明两件事：请求方知道密钥，请求是刚刚发出的。"""

    def __init__(self, base_url: str, app_key: str, secret: str, timeout: float = 10):
        super().__init__(base_url, timeout)
        self.app_key = app_key
        self.secret = secret

    def signed_get(self, path, params=None):
        ts = int(time.time())               # 秒级时间戳，10 位数字
        signed = {**(params or {}), "x_app_key": self.app_key, "x_timestamp": ts, "x_sign": make_sign(self.secret, ts)}
        return self.request("GET", path, params=signed)

    def order_stats(self):
        return self.signed_get("/api/stats/orders")
