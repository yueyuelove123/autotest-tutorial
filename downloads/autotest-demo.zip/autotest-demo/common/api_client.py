"""接口客户端。

每个请求都要做的事收在这里：拼完整地址、带上登录 token、设置超时、记日志、
把请求和响应挂进 Allure 报告。用例里只写业务，比如 api.login(...)、api.create_order(...)。
"""
import json
import logging
import time

import requests

try:
    import allure
except ImportError:  # 没装 allure-pytest 也能用，只是报告里没有附件
    allure = None

log = logging.getLogger("api")
SECRET_KEYS = {"password", "token", "refreshtoken"}   # 比较时字段名先转小写，这里也都写小写


def mask(data):
    """把口令、token 换成 ***，日志和报告里就不会泄露。"""
    if isinstance(data, dict):
        return {k: "***" if k.lower() in SECRET_KEYS else mask(v) for k, v in data.items()}
    if isinstance(data, list):
        return [mask(v) for v in data]
    return data


class ApiClient:
    """通用的 HTTP 客户端，和具体业务无关，换个项目也能直接用。"""

    def __init__(self, base_url: str, timeout: float = 10):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()  # 复用连接，也方便统一设置请求头

    def request(self, method: str, path: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", self.timeout)
        url = self.base_url + path
        start = time.perf_counter()
        resp = self.session.request(method, url, **kwargs)
        cost_ms = (time.perf_counter() - start) * 1000
        log.info("%s %s -> HTTP %s，耗时 %.0f 毫秒", method, path, resp.status_code, cost_ms)
        self._attach(method, url, kwargs, resp, cost_ms)
        return resp

    @staticmethod
    def _attach(method, url, kwargs, resp, cost_ms):
        if allure is None:
            return
        try:
            body = mask(resp.json())
        except ValueError:
            body = resp.text[:2000]
        detail = {
            "请求": {"方法": method, "地址": url, "查询参数": mask(kwargs.get("params")), "请求体": mask(kwargs.get("json"))},
            "响应": {"状态码": resp.status_code, "耗时毫秒": round(cost_ms), "响应体": body},
        }
        allure.attach(
            json.dumps(detail, ensure_ascii=False, indent=2),
            name=f"{method} {url}",
            attachment_type=allure.attachment_type.JSON,
        )


class ShopApi(ApiClient):
    """迷你商城的接口，一个方法对应一个接口。"""

    def __init__(self, base_url: str, timeout: float = 10):
        super().__init__(base_url, timeout)
        self.username = None

    @property
    def token(self):
        return self.session.headers.get("token")

    def login(self, username, password):
        resp = self.request("POST", "/api/login", json={"username": username, "password": password})
        if resp.status_code == 200 and resp.json()["code"] == 0:
            self.session.headers["token"] = resp.json()["data"]["token"]  # 之后的请求自动带上
            self.username = username
        return resp

    def logout(self):
        return self.request("POST", "/api/logout")

    def me(self):
        return self.request("GET", "/api/me")

    def search_products(self, keyword="", page=1, size=10):
        return self.request("GET", "/api/products", params={"keyword": keyword, "page": page, "size": size})

    def get_product(self, product_id):
        return self.request("GET", f"/api/products/{product_id}")

    def create_order(self, items):
        return self.request("POST", "/api/orders", json={"items": items})

    def list_orders(self, status=None):
        return self.request("GET", "/api/orders", params={"status": status} if status else None)

    def get_order(self, order_no):
        return self.request("GET", f"/api/orders/{order_no}")

    def pay_order(self, order_no):
        return self.request("POST", f"/api/orders/{order_no}/pay")

    def cancel_order(self, order_no):
        return self.request("POST", f"/api/orders/{order_no}/cancel")

    def refresh(self, refresh_token):
        """用 refreshToken 换一对新的 token。只负责换，换来的 token 要不要用由调用方决定。"""
        return self.request("POST", "/api/token/refresh", json={"refreshToken": refresh_token})

    def upload_avatar(self, content: bytes, filename="avatar.png", content_type="image/png"):
        """上传头像。类型要自己写上，requests 不会根据文件名去猜。"""
        return self.request("POST", "/api/users/avatar", files={"file": (filename, content, content_type)})

    def get_avatar(self):
        return self.request("GET", "/api/users/avatar")

    def export_orders(self):
        return self.request("GET", "/api/orders/export")

    def create_stock_report(self):
        return self.request("POST", "/api/reports/stock")

    def get_task(self, task_id):
        return self.request("GET", f"/api/tasks/{task_id}")

    def download_task(self, task_id):
        return self.request("GET", f"/api/tasks/{task_id}/download")

    def wait_task(self, task_id, timeout=10, interval=0.5):
        """每隔 interval 秒查一次任务，跑完就返回任务信息；超过 timeout 秒还没跑完就报错。"""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            task = ok(self.get_task(task_id))
            if task["status"] == "completed":
                return task
            assert task["status"] == "processing", f"任务出现了意料之外的状态：{task}"
            time.sleep(interval)
        raise TimeoutError(f"任务 {task_id} 等了 {timeout} 秒还没跑完")

    def create_address(self, address):
        return self.request("POST", "/api/addresses", json=address)

    def list_addresses(self):
        return self.request("GET", "/api/addresses")

    def get_address(self, address_id):
        return self.request("GET", f"/api/addresses/{address_id}")

    def update_address(self, address_id, address):
        return self.request("PUT", f"/api/addresses/{address_id}", json=address)

    def delete_address(self, address_id):
        return self.request("DELETE", f"/api/addresses/{address_id}")


def ok(resp: requests.Response):
    """断言接口调用成功（HTTP 200 且业务码为 0），返回 data 部分。"""
    assert resp.status_code == 200, f"HTTP 状态码是 {resp.status_code}，响应：{resp.text[:300]}"
    body = resp.json()
    assert body["code"] == 0, f"业务失败：code={body['code']}，msg={body['msg']}"
    return body["data"]
