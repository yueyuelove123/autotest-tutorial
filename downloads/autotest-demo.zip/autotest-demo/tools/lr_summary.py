r"""汇总 LoadRunner Controller 的运行结果：各事务的响应时间、按阶梯分档统计、对照 SLA。

用法（在工程根目录执行）：
    python tools/lr_summary.py D:\work\lr-results\demo16
    python tools/lr_summary.py D:\work\lr-results\demo16 --from 60 --to 210    只统计第 60～210 秒
    python tools/lr_summary.py D:\work\lr-results\knee8 --step 60 --skip 15     阶梯加压按每一档汇总
    python tools/lr_summary.py D:\work\lr-results\demo16 --check                有事务失败或 SLA 不达标时退出码为 1

做法：先用 LoadRunner 自带的 LrRawResultsExporter.exe 把结果目录导出成 JSON，放在结果目录下的 raw_json 里，
再按 Analysis 摘要报告的口径计算：响应时间不含思考时间，90% 取从小到大排好序后的第 ceil(0.9 × 个数) 个。
"""
import argparse
import collections
import json
import math
import os
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def export(result: Path) -> Path:
    """导出原始数据。导出过就不再导出；结果目录重新跑过的话，先删掉 raw_json。"""
    raw = result / "raw_json"
    if (raw / "RawData.txt").exists():
        return raw
    lr_path = os.environ.get("LR_PATH")
    if not lr_path:
        sys.exit("找不到环境变量 LR_PATH。装完 LoadRunner 后要重开命令行窗口（第 14 章）")
    exe = Path(lr_path) / "bin" / "LrRawResultsExporter.exe"
    # 注意：不要给它加 -help 参数，它会弹出一个窗口卡住
    subprocess.run([str(exe), "-source_dir", str(result), "-target_dir", str(raw), "-to_json", "-f", "-silent"],
                   check=True, capture_output=True)
    if not (raw / "RawData.txt").exists():
        sys.exit(f"导出失败，{raw} 里没有 RawData.txt。确认 {result} 是 Controller 的结果目录、里面有 .lrr 文件")
    return raw


def load(raw: Path, name: str) -> list:
    p = raw / name
    if not p.exists() or p.stat().st_size < 5:
        return []
    return json.loads(p.read_text(encoding="utf-8-sig"))


def p_value(values: list, percent: float) -> float:
    """百分位数：排好序后取第 ceil(percent% × 个数) 个，和 Analysis 的算法一致。"""
    s = sorted(values)
    return s[max(0, math.ceil(percent / 100 * len(s)) - 1)] if s else 0.0


def read_sla(result: Path) -> list:
    """读结果目录里的 SLAConfiguration.xml，取出按百分位定义的规则：[(事务名, 百分位, 阈值秒)]。"""
    p = result / "SLAConfiguration.xml"
    if not p.exists():
        return []
    root = ET.fromstring(p.read_bytes())
    return [(r.findtext("SubMeasurement"), float(r.findtext("Percentage")), float(r.findtext("Value")))
            for r in root.iter("PercentileRule")]


def main():
    ap = argparse.ArgumentParser(description="汇总 LoadRunner Controller 的运行结果")
    ap.add_argument("result", help="Controller 的结果目录（里面有 .lrr 文件）")
    ap.add_argument("--from", dest="t_from", type=float, default=0, help="从场景开始后第几秒开始统计")
    ap.add_argument("--to", dest="t_to", type=float, default=None, help="统计到第几秒")
    ap.add_argument("--step", type=float, help="阶梯加压每一档多少秒，给了就按档汇总")
    ap.add_argument("--skip", type=float, default=15, help="每一档开头去掉多少秒（用户还在启动，数据不稳）")
    ap.add_argument("--tx", default="02_search,03_order,04_pay", help="按档汇总时看哪几个事务，逗号分隔")
    ap.add_argument("--check", action="store_true", help="有事务失败或 SLA 不达标时，退出码为 1")
    a = ap.parse_args()

    result = Path(a.result)
    raw = export(result)
    info = load(raw, "RunInfo.txt")[0]["RunInfo"]
    start, stop = int(info["Start_time"]), int(info["Stop_time"])
    # 原始数据的时间戳是纳秒、按本地时间记的，RunInfo 里的开始时间按 UTC 记，相差一个时区（Time_Zone，北京时间是 -28800 秒）
    tz = int(info["Time_Zone"])
    # 不给 --to 就统计到最后：最后几个虚拟用户退出时记的数据，时间会比 RunInfo 里的结束时间晚一点
    t_to = a.t_to if a.t_to is not None else math.inf
    records = []
    for r in load(raw, "RawData.txt") + load(raw, "offline.txt"):
        kind, v = next(iter(r.items()))
        records.append((kind, v, int(v["Timestamp"]) / 1e9 + tz - start))

    def seconds(v):
        """事务的响应时间（秒）：结束 − 开始 − 思考时间 − 浪费时间，四个字段都是微秒。"""
        return (int(v["EndTime"]) - int(v["StartTime"]) - int(v.get("ThinkTime", 0)) - int(v.get("WastedTime", 0))) / 1e6

    # ---- 各事务汇总（相当于 Analysis 摘要报告里的事务表）
    passed, failed, stopped = collections.defaultdict(list), collections.Counter(), collections.Counter()
    http = collections.Counter()
    for kind, v, t in records:
        if not a.t_from <= t <= t_to:
            continue
        if kind == "Transaction":
            if v["Status"] == "passed":
                passed[v["Name"]].append(seconds(v))
            elif v["Status"] == "failed":
                failed[v["Name"]] += 1
            else:
                stopped[v["Name"]] += 1
        elif kind == "Datapoint" and v["Name"].startswith("HTTP_"):
            http[v["Name"]] += int(float(v["Value"]))
    span = min(t_to, stop - start) - a.t_from
    print(f"结果 {result.name}，场景持续 {stop - start} 秒，" +
          (f"统计第 {a.t_from:.0f}～{t_to:.0f} 秒" if a.t_to is not None or a.t_from else "统计全程"))
    print("HTTP 状态码：" + ("，".join(f"{k[5:]} 共 {n} 次" for k, n in sorted(http.items())) or "没有记录"))
    print()
    print("| 事务 | 通过 | 失败 | 停止 | 最小 | 平均 | 最大 | 标准偏差 | 90% | 每秒通过 |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for name in sorted(set(passed) | set(failed) | set(stopped)):
        vals = passed[name]
        if vals:
            nums = (f"{min(vals):.3f} | {statistics.mean(vals):.3f} | {max(vals):.3f} | "
                    f"{statistics.pstdev(vals):.3f} | {p_value(vals, 90):.3f}")
        else:
            nums = "- | - | - | - | -"
        print(f"| {name} | {len(vals)} | {failed[name]} | {stopped[name]} | {nums} | {len(vals) / span:.2f} |")

    # ---- 对照 SLA
    problems = [f"事务 {name} 失败 {n} 次" for name, n in sorted(failed.items()) if n]
    rules = read_sla(result)
    if rules:
        print()
        print("| SLA 事务 | 百分位 | 阈值（秒） | 实际（秒） | 结论 |")
        print("|---|---:|---:|---:|---|")
        for name, percent, limit in rules:
            vals = passed.get(name, [])
            if not vals:
                print(f"| {name} | {percent:.0f}% | {limit} | - | 没有数据 |")
                problems.append(f"SLA 事务 {name} 没有通过的数据")
                continue
            actual = p_value(vals, percent)
            ok = actual <= limit
            print(f"| {name} | {percent:.0f}% | {limit} | {actual:.3f} | {'达标' if ok else '不达标'} |")
            if not ok:
                problems.append(f"{name} 的 {percent:.0f}% 响应时间 {actual:.3f} 秒，超过 {limit} 秒")

    # ---- 按阶梯分档
    if a.step:
        print_steps(a, records, seconds, load(raw, "_t_rep.txt"), tz, start, stop)

    if a.check:
        print()
        if problems:
            print("检查不通过：")
            for p in problems:
                print("  - " + p)
            sys.exit(1)
        print("检查通过：没有失败的事务，" + ("SLA 全部达标" if rules else "场景里没有定义 SLA"))


def print_steps(a, records, seconds, vuser_rows, tz, start, stop):
    """阶梯加压：每 step 秒一档，去掉每档开头 skip 秒，统计用户数、每秒请求数、响应时间、失败数、CPU。"""
    names = a.tx.split(",")
    count = math.ceil((stop - start) / a.step)
    steps = [{"rt": collections.defaultdict(list), "fail": 0, "hits": 0, "cpu": []} for _ in range(count)]
    for kind, v, t in records:
        i = int(t // a.step)
        if not (0 <= i < count and t - i * a.step >= a.skip):
            continue
        s = steps[i]
        if kind == "Transaction" and v["Name"] in names:
            if v["Status"] == "passed":
                s["rt"][v["Name"]].append(seconds(v))
            else:
                s["fail"] += 1
        elif kind == "Datapoint" and v["Name"].startswith("HTTP_"):
            s["hits"] += int(float(v["Value"]))
        elif kind == "MonitorDatapoint" and v["Name"].startswith("% Processor Time"):
            s["cpu"].append(float(v["Value"]))   # 场景里加了 Windows 资源监控才有
    # 虚拟用户数只在变化时记一条，每档取统计时段内出现过的最大值
    changes = sorted((int(r["VuserCount"]["Timestamp"]) / 1e9 + tz - start, int(r["VuserCount"]["Value"]))
                     for r in vuser_rows if "VuserCount" in r)
    print()
    print("| 用户数 | 每秒请求数 | " + " | ".join(f"{n} 平均 / 90%（毫秒）" for n in names) + " | 失败 | CPU |")
    print("|---:|---:|" + "---:|" * len(names) + "---:|---:|")
    for i, s in enumerate(steps):
        lo, hi = i * a.step + a.skip, (i + 1) * a.step
        before = [n for t, n in changes if t <= lo]
        users = max(([before[-1]] if before else []) + [n for t, n in changes if lo < t < hi], default=0)
        if not s["hits"] and not s["fail"]:
            continue      # 这一档没有数据，比如场景最后减压的那几秒
        cells = []
        for n in names:
            vals = s["rt"][n]
            cells.append(f"{statistics.mean(vals) * 1000:.0f} / {p_value(vals, 90) * 1000:.0f}" if vals else "-")
        cpu = f"{statistics.mean(s['cpu']):.0f}%" if s["cpu"] else "-"
        print(f"| {users} | {s['hits'] / (a.step - a.skip):.1f} | " + " | ".join(cells) + f" | {s['fail']} | {cpu} |")


if __name__ == "__main__":
    main()
