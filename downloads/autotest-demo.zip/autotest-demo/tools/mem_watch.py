r"""每隔一段时间记录一个进程占用的内存，写成 CSV，稳定性测试时用来看内存有没有一直涨（只能在 Windows 上用）。

用法（在工程根目录执行）：
    python tools/mem_watch.py <进程号> <一共记录多少秒> <每隔几秒记一次> <输出的 CSV 文件>
    python tools/mem_watch.py 12345 2000 30 D:\work\lr-results\stable_mem.csv

练习网站的进程号：在 PowerShell 里执行 netstat -ano | findstr :8000，LISTENING 那一行最后的数字就是。
CSV 有三列：开始后第几秒、工作集（MB）、专用字节（MB）。工作集是进程现在占着的物理内存；
专用字节是进程自己申请、别的进程不能共用的内存，看内存泄漏主要看它。
"""
import csv
import ctypes
import sys
import time
from ctypes import wintypes


class ProcessMemoryCounters(ctypes.Structure):
    """Windows 的 PROCESS_MEMORY_COUNTERS_EX 结构，字段顺序不能改。"""
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                ("PrivateUsage", ctypes.c_size_t)]


def main():
    if len(sys.argv) != 5:
        sys.exit("用法：python tools/mem_watch.py <进程号> <一共记录多少秒> <每隔几秒记一次> <输出的 CSV 文件>")
    pid, total, step, out = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), sys.argv[4]
    # 只要「查询信息」和「读内存」两种权限，不需要管理员
    handle = ctypes.windll.kernel32.OpenProcess(0x1000 | 0x0010, False, pid)
    if not handle:
        sys.exit(f"打不开进程 {pid}，检查进程号对不对、进程还在不在")
    start = time.time()
    with open(out, "w", newline="", encoding="utf-8-sig") as f:    # 带 BOM，Excel 直接打开不乱码
        writer = csv.writer(f)
        writer.writerow(["秒", "工作集MB", "专用字节MB"])
        while time.time() - start <= total:
            c = ProcessMemoryCounters()
            c.cb = ctypes.sizeof(c)
            if not ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(c), c.cb):
                print("进程已经退出，停止记录")
                break
            row = [round(time.time() - start), round(c.WorkingSetSize / 2**20, 1), round(c.PrivateUsage / 2**20, 1)]
            writer.writerow(row)
            f.flush()                      # 每记一行就写到磁盘，中途停掉也不丢数据
            print(*row, sep="\t")
            time.sleep(step)


if __name__ == "__main__":
    main()
