﻿<#
用命令行运行一个 LoadRunner 场景，再检查结果，给压测机上的流水线用（第 19 章 19.5.4 节）。

用法（在工程根目录执行）：
    powershell -NoProfile -ExecutionPolicy Bypass -File tools\run_lr.ps1 -Scenario D:\work\autotest-demo\lr\scenarios\demo16.lrs -ResultRoot D:\work\lr-results

退出码：0 表示没有失败的事务、SLA 全部达标；1 表示检查不通过；2 表示场景没有正常跑完。
#>
param(
    [Parameter(Mandatory = $true)][string]$Scenario,     # 场景文件（.lrs）的完整路径
    [Parameter(Mandatory = $true)][string]$ResultRoot,   # 结果放在哪个文件夹下
    [int]$TimeoutMinutes = 60                            # 场景最多跑多久，超时就结束 Controller
)

if (-not $env:LR_PATH) {
    Write-Host "找不到环境变量 LR_PATH，这台机器上没有装 LoadRunner，或者装完没有重开命令行窗口"
    exit 2
}

# 每次用一个新的结果目录：-ResultName 指向已有的目录时会被直接覆盖
$name = [IO.Path]::GetFileNameWithoutExtension($Scenario) + "_" + (Get-Date -Format "yyyyMMdd_HHmmss")
$result = Join-Path $ResultRoot $name
Write-Host "运行场景 $Scenario，结果放在 $result"

$wlrun = Join-Path $env:LR_PATH "bin\Wlrun.exe"
$p = Start-Process $wlrun -ArgumentList "-TestPath", $Scenario, "-ResultName", $result, "-Run" -PassThru
if (-not $p.WaitForExit($TimeoutMinutes * 60 * 1000)) {
    Stop-Process -Id $p.Id -Force
    Write-Host "超过 $TimeoutMinutes 分钟还没有结束，已经强制结束 Controller"
    exit 2
}

# Wlrun.exe 的退出码不反映事务结果（第 16 章 16.12 节），这里只看结果文件有没有生成
if (-not (Get-ChildItem $result -Filter *.lrr -ErrorAction SilentlyContinue)) {
    Write-Host "结果目录里没有 .lrr 文件，场景没有正常跑完"
    exit 2
}

# 优先用工程里虚拟环境的 Python
$python = if (Test-Path ".venv\Scripts\python.exe") { ".venv\Scripts\python.exe" } else { "python" }
& $python tools/lr_summary.py $result --check
exit $LASTEXITCODE
