"""生成一张 1×1 像素的 PNG 图片，给上传头像的用例当测试文件用。只用 Python 自带的库。

运行：python tools/make_png.py data/avatar.png
"""
import struct
import sys
import zlib
from pathlib import Path


def chunk(kind: bytes, body: bytes) -> bytes:
    """PNG 文件由若干「块」组成：长度、类型、内容、校验码。"""
    return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))


def make_png(width=1, height=1) -> bytes:
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)   # 8 位色深，RGBA
    pixels = b"".join(b"\x00" + b"\x5c\x6b\xc0\xff" * width for _ in range(height))   # 每行前面一个 0 表示不压缩
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b"")


if __name__ == "__main__":
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "data/avatar.png")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(make_png())
    print(f"已生成 {target}，{target.stat().st_size} 字节")
