"""把测试结果发到企业微信群。

用法：
    pytest --junitxml=reports/junit.xml
    python tools/notify.py reports/junit.xml
群机器人的地址放在环境变量 WECOM_WEBHOOK 里；没设置时只把要发的内容打印出来，不发送。
"""
import os
import sys
import xml.etree.ElementTree as ET

import requests


def read_junit(path):
    """从 pytest 生成的 junit.xml 里读出总数、失败数、跳过数、耗时和失败用例名。"""
    root = ET.parse(path).getroot()
    suite = root if root.tag == "testsuite" else root.find("testsuite")
    total = int(suite.get("tests"))
    failed = int(suite.get("failures")) + int(suite.get("errors"))
    skipped = int(suite.get("skipped"))
    failed_names = [
        f"{case.get('classname')}.{case.get('name')}"
        for case in suite.iter("testcase")
        if case.find("failure") is not None or case.find("error") is not None
    ]
    return total, failed, skipped, float(suite.get("time")), failed_names


def build_message(total, failed, skipped, seconds, failed_names):
    title = "全部通过" if failed == 0 else f"有 {failed} 条失败"
    lines = [
        f"### 自动化测试结果：{title}",
        f"> 总数 {total}，通过 {total - failed - skipped}，失败 {failed}，跳过 {skipped}，耗时 {seconds:.0f} 秒",
    ]
    lines += [f"- {name}" for name in failed_names[:10]]
    if len(failed_names) > 10:
        lines.append(f"- 还有 {len(failed_names) - 10} 条，详见测试报告")
    return "\n".join(lines)


def main():
    if len(sys.argv) != 2:
        sys.exit("用法：python tools/notify.py <junit.xml 的路径>")
    text = build_message(*read_junit(sys.argv[1]))
    webhook = os.getenv("WECOM_WEBHOOK")
    if not webhook:
        print("没有设置 WECOM_WEBHOOK，只打印不发送：\n" + text)
        return
    resp = requests.post(webhook, json={"msgtype": "markdown", "markdown": {"content": text}}, timeout=10)
    body = resp.json()
    if resp.status_code != 200 or body.get("errcode") != 0:   # 企业微信出错时 HTTP 也是 200，要看 errcode
        sys.exit(f"发送失败：{resp.text}")
    print("已发送到企业微信群")


if __name__ == "__main__":
    main()
