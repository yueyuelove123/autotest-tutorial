"""全局夹具（fixture）：配置、账号、接口客户端、测试数据。tests 下所有用例都能直接用。"""
import pytest

from common.api_client import ShopApi, ok
from common.config import load_config


@pytest.fixture(scope="session")
def config():
    return load_config()


@pytest.fixture(scope="session")
def base_url(config):
    """被测网站的地址。pytest-playwright 也读这个夹具，所以 page.goto 里只写路径就行。"""
    return config["base_url"]


@pytest.fixture(scope="session")
def worker_index(worker_id):
    """当前进程的编号。worker_id 由 pytest-xdist 提供：不并行时是 master，并行时是 gw0、gw1……"""
    return 0 if worker_id == "master" else int(worker_id.removeprefix("gw"))


@pytest.fixture(scope="session")
def account(config, worker_id, worker_index):
    """本进程用的账号。

    一个进程跑全部用例时用主账号；并行执行（pytest -n 4）时每个进程各用账号池里的一个，
    免得几个进程同时改同一个账号的余额，让余额断言互相干扰。
    """
    if worker_id == "master":
        return config["accounts"]["main"]
    pool = config["accounts"]["pool"]
    return {"username": f"{pool['prefix']}{worker_index + 1:03d}", "password": pool["password"]}


@pytest.fixture(scope="session")
def api(config, account):
    """已登录的接口客户端。整轮测试只登录一次，所有用例共用。"""
    client = ShopApi(config["base_url"], timeout=config["timeout"])
    ok(client.login(account["username"], account["password"]))
    return client


@pytest.fixture
def guest(config):
    """没登录的接口客户端，每条用例一个新的。"""
    return ShopApi(config["base_url"], timeout=config["timeout"])


# 便宜、库存充足的商品。并行执行时每个进程用不同的一件：库存是所有用户共享的，
# 几个进程同时买同一件商品，「库存少了 3 件」这种断言就会互相干扰
CHEAP_PRODUCTS = ["中性笔", "笔记本", "毛巾", "收纳盒", "跳绳", "马克杯", "运动水壶", "USB-C 数据线"]


@pytest.fixture
def product(api, worker_index):
    """下单类用例用的商品。"""
    name = CHEAP_PRODUCTS[worker_index % len(CHEAP_PRODUCTS)]
    items = ok(api.search_products(keyword=name))["items"]
    assert items, f"练习网站里应该有「{name}」这个商品"
    return items[0]


@pytest.fixture
def unpaid_order(api, product):
    """准备一张待支付订单；用例结束后它要是还没支付，就取消掉，把库存还回去。"""
    order = ok(api.create_order([{"productId": product["id"], "quantity": 1}]))
    yield order
    if ok(api.get_order(order["orderNo"]))["status"] == "UNPAID":
        ok(api.cancel_order(order["orderNo"]))
