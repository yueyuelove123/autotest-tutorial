"""文件下载的用例：订单导出成 CSV。"""
import csv
import io

import allure
import pytest


@allure.feature("订单")
@allure.title("导出订单：返回带 BOM 的 CSV 附件，里面有刚下的那一单")
def test_export_orders(api, product, unpaid_order):
    resp = api.export_orders()
    # 1. 状态码和响应头：确认拿到的是一个要下载的 CSV 文件
    assert resp.status_code == 200
    assert resp.headers["Content-Type"].startswith("text/csv")
    assert resp.headers["Content-Disposition"] == "attachment; filename=orders.csv"
    # 2. 开头 3 个字节是 BOM，Excel 靠它认出这是 UTF-8
    assert resp.content.startswith(b"\xef\xbb\xbf")
    # 3. 解析内容：刚下的订单在里面，各列的值都对
    rows = list(csv.DictReader(io.StringIO(resp.content.decode("utf-8-sig"))))
    mine = [row for row in rows if row["订单号"] == unpaid_order["orderNo"]]
    assert len(mine) == 1, f"导出文件里应该正好有一行是订单 {unpaid_order['orderNo']}"
    assert mine[0]["商品"] == f"{product['name']} ×1"
    assert float(mine[0]["金额(元)"]) == pytest.approx(unpaid_order["amount"])
    assert mine[0]["状态"] == "待支付"


@allure.feature("订单")
@allure.title("导出链接可以把 token 放在查询参数里，什么都不带返回 401")
def test_export_with_token_in_query(api, guest):
    resp = guest.request("GET", "/api/orders/export", params={"token": api.token})
    assert resp.status_code == 200
    assert resp.headers["Content-Disposition"] == "attachment; filename=orders.csv"
    assert guest.export_orders().status_code == 401
