"""token 刷新的用例：换一对新的，旧的 refreshToken 只能用一次。这几条不需要等 token 过期就能测。"""
import allure
import pytest

from common.api_client import ShopApi, ok


@pytest.fixture
def fresh_login(config):
    """专用的登录：刷新会换掉 token，不碰共享的 api 夹具。"""
    client = ShopApi(config["base_url"], timeout=config["timeout"])
    data = ok(client.login("alice", "alice123"))
    return client, data


@allure.feature("账号")
@allure.title("用 refreshToken 换到一对新的 token，新 token 能正常使用")
def test_refresh_gives_new_pair(fresh_login):
    client, data = fresh_login
    new = ok(client.refresh(data["refreshToken"]))
    assert new["token"] != data["token"]
    assert new["refreshToken"] != data["refreshToken"]
    client.session.headers["token"] = new["token"]
    assert ok(client.me())["username"] == "alice"


@allure.feature("账号")
@allure.title("refreshToken 只能用一次，第二次返回 40103")
def test_refresh_token_is_one_time(fresh_login):
    client, data = fresh_login
    ok(client.refresh(data["refreshToken"]))
    resp = client.refresh(data["refreshToken"])
    assert resp.status_code == 401
    assert resp.json()["code"] == 40103


@allure.feature("账号")
@allure.title("编造的 refreshToken 返回 40103")
def test_refresh_token_invalid(guest):
    resp = guest.refresh("0" * 32)
    assert resp.status_code == 401
    assert resp.json() == {"code": 40103, "msg": "刷新 token 无效", "data": None}
