"""开放接口（订单统计）的用例：签名正确能查到数据，四种验签失败各有各的业务码。"""
import time

import allure
import pytest

from common.open_api import OpenApi, make_sign

URL = "/api/stats/orders"


@pytest.fixture
def open_api(config):
    cfg = config["open_api"]
    return OpenApi(config["base_url"], cfg["app_key"], cfg["secret"], timeout=config["timeout"])


def signed_params(open_api, ts=None, **wrong):
    """一组正确的签名参数；wrong 里给的项会覆盖掉对应的正确值，用来造各种错误。"""
    ts = int(time.time()) if ts is None else ts
    params = {"x_app_key": open_api.app_key, "x_timestamp": ts, "x_sign": make_sign(open_api.secret, ts)}
    params.update(wrong)
    return params


@allure.feature("开放接口")
@allure.title("签名正确时能查到订单统计")
def test_stats_ok(open_api):
    resp = open_api.order_stats()
    assert resp.status_code == 200
    body = resp.json()
    assert body["code"] == 0
    assert body["data"]["paidOrders"] <= body["data"]["totalOrders"]


SIGN_ERRORS = [
    ("appKey不对", {"x_app_key": "wrong-key"}, 4011, "appKey 不正确"),
    ("时间戳不是数字", {"x_timestamp": "abc"}, 4012, "时间戳格式不对"),
    ("签名不对", {"x_sign": "0" * 32}, 4014, "签名不正确"),
]


@allure.feature("开放接口")
@allure.title("验签失败：{title}")
@pytest.mark.parametrize("title, wrong, code, msg", SIGN_ERRORS, ids=[c[0] for c in SIGN_ERRORS])
def test_stats_sign_error(open_api, title, wrong, code, msg):
    resp = open_api.request("GET", URL, params=signed_params(open_api, **wrong))
    assert resp.status_code == 401
    assert resp.json()["code"] == code
    assert resp.json()["msg"] == msg


@allure.feature("开放接口")
@allure.title("时间戳超出前后 300 秒：签名本身是对的也会被拦")
@pytest.mark.parametrize("offset", [-310, 310], ids=["慢了310秒", "快了310秒"])
def test_stats_timestamp_out_of_window(open_api, offset):
    resp = open_api.request("GET", URL, params=signed_params(open_api, ts=int(time.time()) + offset))
    assert resp.status_code == 401
    assert resp.json()["code"] == 4013


@allure.feature("开放接口")
@allure.title("时间戳在前后 300 秒以内都能通过")
@pytest.mark.parametrize("offset", [-290, 290], ids=["慢了290秒", "快了290秒"])
def test_stats_timestamp_in_window(open_api, offset):
    resp = open_api.request("GET", URL, params=signed_params(open_api, ts=int(time.time()) + offset))
    assert resp.json()["code"] == 0


@allure.feature("开放接口")
@allure.title("把时间戳写成毫秒会被当成超出范围")
def test_stats_millisecond_timestamp(open_api):
    ts_ms = int(time.time() * 1000)
    resp = open_api.request("GET", URL, params=signed_params(open_api, ts=ts_ms))
    assert resp.json()["code"] == 4013
