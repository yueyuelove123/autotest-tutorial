"""token 自动续期的用例。

这个文件要在 token 会过期的网站上跑：起练习网站前先设 SHOP_TOKEN_TTL=2（两秒过期）。
网站没开这个开关时，下面的探测夹具会让整个文件跳过，并说明原因。
"""
import time
from concurrent.futures import ThreadPoolExecutor

import pytest
import requests

from common.api_client import ok
from common.auto_refresh_client import AutoRefreshApi, SessionExpired

pytestmark = pytest.mark.token_ttl      # 平时跑全部用例时可以用 -m "not token_ttl" 跳过这个文件


@pytest.fixture(scope="module", autouse=True)
def require_token_ttl(config):
    """先探测网站开没开 SHOP_TOKEN_TTL：登录后等 2.5 秒，旧 token 还能用就说明没开。"""
    base = config["base_url"]
    token = requests.post(f"{base}/api/login", json={"username": "alice", "password": "alice123"},
                          timeout=10).json()["data"]["token"]
    time.sleep(2.5)
    code = requests.get(f"{base}/api/me", headers={"token": token}, timeout=10).json()["code"]
    if code != 40102:
        pytest.skip("练习网站没有开 SHOP_TOKEN_TTL=2，token 不会过期，续期用例没法验证")


@pytest.fixture
def client(config):
    api = AutoRefreshApi(config["base_url"], timeout=config["timeout"])
    ok(api.login("alice", "alice123"))
    return api


def test_token_expires_and_refreshes(client):
    old_token = client.token
    time.sleep(3)                                   # 等 token 过期
    data = ok(client.me())                          # 过期了也能正常拿到结果
    assert data["username"] == "alice"
    assert client.token != old_token                # 说明客户端确实换过一次 token


def test_concurrent_requests_refresh_once(client):
    time.sleep(3)
    with ThreadPoolExecutor(max_workers=5) as pool:  # 5 个请求同时撞上过期
        results = list(pool.map(lambda _: client.me(), range(5)))
    assert all(r.json()["code"] == 0 for r in results)


def test_refresh_token_invalid(client):
    time.sleep(3)
    client.refresh_token = "not-a-real-refresh-token"
    with pytest.raises(SessionExpired):
        client.me()
