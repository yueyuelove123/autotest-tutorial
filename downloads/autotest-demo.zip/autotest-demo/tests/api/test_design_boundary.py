"""等价类与边界值的用例：购买数量、每页条数、昵称长度、一次下单的行数。

设计思路见教程第 5 章 5.2 节：先把每个参数的有效区间和边界值列成表格，
再翻译成参数化用例。有效边界用真实下单验证并当场取消，跑多少次都不消耗数据。
"""
import allure
import pytest

from common.api_client import ShopApi, ok

# 购买数量的文档约定是 1～999：有效边界 1、2、998、999 都该成功，
# 无效等价类 0、负数、1000、小数、非数字、空值都该被 422 拦下
QUANTITY_VALID = [1, 2, 998, 999]
QUANTITY_INVALID = [
    ("数量为0", 0),
    ("数量为负数", -1),
    ("数量为1000", 1000),
    ("数量是小数", 1.5),
    ("数量不是数字", "abc"),
    ("数量为空", None),
]


@allure.feature("用例设计")
@allure.title("购买数量取有效边界值 {quantity} 件时下单成功，库存随之减少")
@pytest.mark.parametrize("quantity", QUANTITY_VALID, ids=[f"买{q}件" for q in QUANTITY_VALID])
def test_quantity_valid_boundary(api, product, quantity):
    stock_before = ok(api.get_product(product["id"]))["stock"]
    order = ok(api.create_order([{"productId": product["id"], "quantity": quantity}]))
    try:
        assert order["status"] == "UNPAID"
        assert order["amount"] == pytest.approx(product["price"] * quantity)
        assert ok(api.get_product(product["id"]))["stock"] == stock_before - quantity
    finally:
        ok(api.cancel_order(order["orderNo"]))   # 归还库存，下次运行还是同样的初始状态


@allure.feature("用例设计")
@allure.title("购买数量取无效值时返回 422：{title}")
@pytest.mark.parametrize("title, quantity", QUANTITY_INVALID, ids=[c[0] for c in QUANTITY_INVALID])
def test_quantity_invalid(api, product, title, quantity):
    resp = api.create_order([{"productId": product["id"], "quantity": quantity}])
    assert resp.status_code == 422
    body = resp.json()
    assert body["code"] == 422
    assert body["data"][0]["field"].endswith("quantity")


@allure.feature("用例设计")
@allure.title("数量传字符串数字也能下单：接口的校验比界面宽")
def test_quantity_type_lenient(api, product):
    """等价类不能只按文档划：实际系统可能接受文档没提的写法，这类偏差也要有用例盯着。"""
    stock_before = ok(api.get_product(product["id"]))["stock"]
    order = ok(api.create_order([{"productId": product["id"], "quantity": "3"}]))   # 字符串数字
    try:
        assert order["amount"] == pytest.approx(product["price"] * 3)
    finally:
        ok(api.cancel_order(order["orderNo"]))
    assert ok(api.get_product(product["id"]))["stock"] == stock_before


# 每页条数的文档约定是 1～50：1 和 50 是有效边界，0 和 51 是无效边界
SIZE_CASES = [
    ("每页1条", 1, 200, 1),
    ("每页50条", 50, 200, 25),
    ("每页0条", 0, 422, None),
    ("每页51条", 51, 422, None),
]


@allure.feature("用例设计")
@allure.title("每页条数取边界值：{title}")
@pytest.mark.parametrize("title, size, status, expect_count", SIZE_CASES, ids=[c[0] for c in SIZE_CASES])
def test_size_boundary(guest, title, size, status, expect_count):
    resp = guest.search_products(size=size)
    assert resp.status_code == status
    if status == 200:
        data = resp.json()["data"]
        assert data["size"] == size
        assert len(data["items"]) == expect_count    # 练习网站一共 25 件商品


# 25 件商品、每页 10 件：第 3 页是最后一页，只剩 5 件；第 4 页已经翻过头。
# 参数名用 page_no 不用 page：page 是 pytest-playwright 的夹具名，重名会被它接管
PAGE_CASES = [
    ("最后一页", 3, 5),
    ("最后一页之后", 4, 0),
]


@allure.feature("用例设计")
@allure.title("翻页的边界：{title}")
@pytest.mark.parametrize("title, page_no, expect_count", PAGE_CASES, ids=[c[0] for c in PAGE_CASES])
def test_page_boundary(guest, title, page_no, expect_count):
    data = ok(guest.search_products(page=page_no, size=10))
    assert data["total"] == 25                     # 翻到哪一页，总数都不变
    assert len(data["items"]) == expect_count


# 昵称的文档约定是 2～20 个字
NICKNAME_INVALID = [
    ("昵称只有1个字", "超"),
    ("昵称超过20个字", "超" * 21),
    ("昵称不是字符串", 123),
]


@allure.feature("用例设计")
@allure.title("昵称长度非法时返回 422：{title}")
@pytest.mark.parametrize("title, nickname", NICKNAME_INVALID, ids=[c[0] for c in NICKNAME_INVALID])
def test_nickname_invalid(config, title, nickname):
    client = ShopApi(config["base_url"])
    acc = config["accounts"]["login"]
    ok(client.login(acc["username"], acc["password"]))
    resp = client.request("PUT", "/api/users/me", json={"nickname": nickname})
    assert resp.status_code == 422


NICKNAME_VALID = [
    ("昵称2个字", "阿宝"),
    ("昵称20个字", "超" * 20),
]


@allure.feature("用例设计")
@allure.title("昵称取有效边界值时能改成功：{title}")
@pytest.mark.parametrize("title, nickname", NICKNAME_VALID, ids=[c[0] for c in NICKNAME_VALID])
def test_nickname_valid_boundary(config, title, nickname):
    client = ShopApi(config["base_url"])
    acc = config["accounts"]["login"]
    ok(client.login(acc["username"], acc["password"]))
    try:
        resp = client.request("PUT", "/api/users/me", json={"nickname": nickname})
        assert resp.status_code == 200
        assert resp.json()["data"]["nickname"] == nickname
    finally:
        client.request("PUT", "/api/users/me", json={"nickname": "bob"})   # 恢复原昵称，不留脏数据


@allure.feature("用例设计")
@allure.title("两个空格能过长度校验，存进去变成空昵称")
def test_nickname_whitespace_quirk(config):
    """边界值设计能挖到的真实问题：接口先做长度校验、后去掉首尾空格，
    两个空格恰好绕过校验。算不算缺陷由团队定，但测试要能发现它。"""
    client = ShopApi(config["base_url"])
    acc = config["accounts"]["login"]
    ok(client.login(acc["username"], acc["password"]))
    try:
        assert client.request("PUT", "/api/users/me", json={"nickname": "  "}).status_code == 200
        assert ok(client.me())["nickname"] == ""
    finally:
        client.request("PUT", "/api/users/me", json={"nickname": "bob"})


# 一次下单最多 20 行：20 行是有效边界，21 行是无效边界
ITEMS_COUNT_CASES = [
    ("20行", 20, 200),
    ("21行", 21, 422),
]


@allure.feature("用例设计")
@allure.title("一次下单的行数取边界值：{title}")
@pytest.mark.parametrize("title, lines, status", ITEMS_COUNT_CASES, ids=[c[0] for c in ITEMS_COUNT_CASES])
def test_items_count_boundary(api, product, title, lines, status):
    resp = api.create_order([{"productId": product["id"], "quantity": 1} for _ in range(lines)])
    assert resp.status_code == status
    if status == 200:
        ok(api.cancel_order(resp.json()["data"]["orderNo"]))   # 下单成功的当场取消，归还库存
