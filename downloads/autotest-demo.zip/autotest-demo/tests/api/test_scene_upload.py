"""文件上传的用例：头像只收 jpg、png，不超过 200 KB。"""
import allure
import pytest

from common.api_client import ok

# 一张 1×1 像素的红色 PNG 图片，一共 69 个字节。四行依次是：文件头、尺寸信息、像素数据、结束标记
PNG = bytes.fromhex(
    "89504e470d0a1a0a"
    "0000000d4948445200000001000000010802000000907753de"
    "0000000c49444154789c63f8cfc0000003010100c9fe92ef"
    "0000000049454e44ae426082"
)
LIMIT = 200 * 1024       # 上限 200 KB，也就是 204800 字节


def png_of_size(size):
    """造一个指定大小的「PNG」：开头 8 个字节是 PNG 的文件头，后面用 0 补齐。只在内存里，不落盘。"""
    return PNG[:8] + b"0" * (size - 8)


@allure.feature("账号")
@allure.title("上传 png 头像成功，hasAvatar 变成 true，下载回来和上传的一样")
def test_upload_avatar(api):
    data = ok(api.upload_avatar(PNG))
    assert data == {"size": 69, "type": "image/png"}
    assert ok(api.me())["hasAvatar"] is True
    resp = api.get_avatar()
    assert resp.status_code == 200
    assert resp.headers["Content-Type"] == "image/png"
    assert resp.content == PNG


@allure.feature("账号")
@allure.title("上传 txt 文件被拒绝，提示只支持 jpg 或 png")
def test_upload_avatar_wrong_type(api):
    body = api.upload_avatar(b"hello", filename="note.txt", content_type="text/plain").json()
    assert body["code"] == 4001
    assert body["msg"] == "头像只支持 jpg 或 png 格式"


SIZE_CASES = [
    ("正好200KB", LIMIT, 0),
    ("超过1个字节", LIMIT + 1, 4002),
]


@allure.feature("账号")
@allure.title("头像大小的边界：{title}")
@pytest.mark.parametrize("title, size, code", SIZE_CASES, ids=[c[0] for c in SIZE_CASES])
def test_upload_avatar_size_limit(api, title, size, code):
    body = api.upload_avatar(png_of_size(size)).json()
    assert body["code"] == code


@allure.feature("账号")
@allure.title("没带文件时返回 422，指出缺的是 file 字段")
def test_upload_avatar_missing_file(api):
    resp = api.request("POST", "/api/users/avatar")
    assert resp.status_code == 422
    assert resp.json()["data"] == [{"field": "file", "reason": "Field required"}]
