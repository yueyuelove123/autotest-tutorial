"""越权测试（水平越权）：用自己的 token 去动别人的数据，系统必须拦住。

练习网站用 SHOP_IDOR_BUG=1 启动时，查看和修改接口不校验归属，这里的用例会失败（6.6 节）。
"""
import allure
import pytest

from common.api_client import ShopApi, ok

pytestmark = pytest.mark.idor     # 整个文件的用例都打上 idor 标记，可以用 pytest -m idor 单独跑

NEW_ADDRESS = {"receiver": "李四", "phone": "13900002222", "detail": "幸福路 8 号 3 单元"}


@pytest.fixture
def bob(config):
    client = ShopApi(config["base_url"], timeout=config["timeout"])
    ok(client.login("bob", "bob123"))
    return client


@pytest.fixture
def bob_address(bob):
    """bob 名下的一个收货地址，用例结束后 bob 自己删掉。"""
    address = ok(bob.create_address({"receiver": "王小明", "phone": "13800001111", "detail": "人民路 1 号院 2 栋"}))
    yield address
    bob.delete_address(address["id"])


# 路径里带地址编号的接口一个不漏地列出来：编号换成 bob 的地址，用 alice 的 token 去调
ID_APIS = [
    ("查看", "GET", "/api/addresses/{id}", None),
    ("修改", "PUT", "/api/addresses/{id}", NEW_ADDRESS),
    ("删除", "DELETE", "/api/addresses/{id}", None),
]


@allure.feature("收货地址")
@allure.title("越权：用别人的地址编号{action}，返回地址不存在")
@pytest.mark.parametrize("action, method, path, body", ID_APIS, ids=[c[0] for c in ID_APIS])
def test_cannot_touch_others_address(api, bob, bob_address, action, method, path, body):
    resp = api.request(method, path.format(id=bob_address["id"]), json=body)
    assert resp.json()["code"] == 5001, f"{action}别人的地址成功了，存在越权：{resp.json()}"
    # 只看返回码还不够，再回到 bob 那边确认地址原封不动
    assert ok(bob.get_address(bob_address["id"])) == bob_address


@allure.feature("收货地址")
@allure.title("别人的地址和不存在的地址，返回一模一样")
def test_others_address_looks_like_missing(api, bob_address):
    others = api.get_address(bob_address["id"]).json()
    missing = api.get_address(999999).json()
    assert others == missing
