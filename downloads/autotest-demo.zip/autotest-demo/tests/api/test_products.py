"""商品接口的用例。"""
import json
from pathlib import Path

import allure
import pytest
from jsonschema import validate

from common.api_client import ok

PRODUCT_SCHEMA = json.loads((Path(__file__).parents[2] / "data" / "product_schema.json").read_text(encoding="utf-8"))


@allure.feature("商品")
@allure.title("按关键词搜索，结果都包含关键词")
@pytest.mark.smoke
def test_search_by_keyword(guest):
    data = ok(guest.search_products(keyword="耳机"))
    assert data["total"] == 2
    assert all("耳机" in p["name"] for p in data["items"])


@allure.feature("商品")
@allure.title("搜不到时返回空列表")
def test_search_no_result(guest):
    data = ok(guest.search_products(keyword="不存在的商品"))
    assert data["total"] == 0
    assert data["items"] == []


@allure.feature("商品")
@allure.title("分页：第一页和第二页没有重复商品")
def test_search_pagination(guest):
    page1 = ok(guest.search_products(page=1, size=5))["items"]
    page2 = ok(guest.search_products(page=2, size=5))["items"]
    assert len(page1) == 5 and len(page2) == 5
    assert {p["id"] for p in page1}.isdisjoint({p["id"] for p in page2})


INVALID_PARAMS = [
    ("页码为0", {"page": 0}, "page"),
    ("每页0条", {"size": 0}, "size"),
    ("每页超过50条", {"size": 51}, "size"),
    ("页码不是数字", {"page": "abc"}, "page"),
]


@allure.feature("商品")
@allure.title("搜索参数非法时返回 422：{title}")
@pytest.mark.parametrize("title, params, field", INVALID_PARAMS, ids=[c[0] for c in INVALID_PARAMS])
def test_search_invalid_params(guest, title, params, field):
    resp = guest.request("GET", "/api/products", params=params)
    assert resp.status_code == 422
    assert resp.json()["data"][0]["field"] == field


@allure.feature("商品")
@allure.title("商品详情的字段和类型符合约定")
def test_product_detail_schema(guest):
    data = ok(guest.get_product(1))
    validate(instance=data, schema=PRODUCT_SCHEMA)  # 字段缺了、多了、类型不对都会报错


@allure.feature("商品")
@allure.title("查询不存在的商品返回业务码 2001")
def test_product_not_found(guest):
    body = guest.get_product(99999).json()
    assert body["code"] == 2001
    assert body["msg"] == "商品不存在"
