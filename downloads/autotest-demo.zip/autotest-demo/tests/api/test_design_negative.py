"""负面与异常场景的用例：token 的三种坏法、用户之间的数据隔离。

设计思路：不光测「正常用户带正常 token」，还要故意把凭证弄坏、去碰别人的数据，
确认系统在这些情况下给出的都是安全的答案。
"""
import secrets

import allure
import pytest

from common.api_client import ShopApi, ok

UNKNOWN_TOKEN = secrets.token_hex(16)   # 每轮运行都不同，但永远不会是服务器发过的

# 三种坏 token，预期都一样：HTTP 401，业务码 40101
BAD_TOKENS = [
    ("不带token", None),
    ("伪造的token", "totally-fake-token"),
    ("格式对但不存在的token", UNKNOWN_TOKEN),
]


@allure.feature("用例设计")
@allure.title("token 三种坏法都被拦下：{title}")
@pytest.mark.parametrize("title, token", BAD_TOKENS, ids=[c[0] for c in BAD_TOKENS])
def test_bad_token(config, title, token):
    client = ShopApi(config["base_url"])
    if token is not None:
        client.session.headers["token"] = token
    resp = client.me()
    assert resp.status_code == 401
    assert resp.json()["code"] == 40101


@pytest.fixture
def bob(config):
    """另一个用户 bob 的客户端，专门拿来碰 alice（主账号）的数据。"""
    acc = config["accounts"]["login"]
    client = ShopApi(config["base_url"])
    ok(client.login(acc["username"], acc["password"]))
    return client


ISOLATION_ACTIONS = ["查询", "支付", "取消"]


@allure.feature("用例设计")
@allure.title("数据隔离：bob {action} alice 的订单，得到订单不存在")
@pytest.mark.parametrize("action", ISOLATION_ACTIONS, ids=[f"{a}别人的订单" for a in ISOLATION_ACTIONS])
def test_isolation_between_users(api, bob, unpaid_order, action):
    # 对照组：先用 alice 自己查一次，确认这张订单真的存在，排除「订单号写错了」的假通过
    assert ok(api.get_order(unpaid_order["orderNo"]))["status"] == "UNPAID"

    actions = {"查询": bob.get_order, "支付": bob.pay_order, "取消": bob.cancel_order}
    body = actions[action](unpaid_order["orderNo"]).json()
    assert body["code"] == 3001                    # 按「订单不存在」处理，不提示无权限
    assert ok(api.get_order(unpaid_order["orderNo"]))["status"] == "UNPAID"   # 订单原封不动


@allure.feature("用例设计")
@allure.title("数据隔离：别人的订单不会出现在 bob 的订单列表里")
def test_isolation_order_list(bob, unpaid_order):
    order_nos = [o["orderNo"] for o in ok(bob.list_orders())["items"]]
    assert unpaid_order["orderNo"] not in order_nos
