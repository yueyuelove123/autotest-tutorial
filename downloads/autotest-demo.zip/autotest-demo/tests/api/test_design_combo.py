"""组合与串联的用例：多行商品合并、两种商品一单、下单与支付的时序、余额的边界。

这一类用例要一次调多个接口，按业务上的先后顺序串起来，检查中间状态。
"""
import allure
import pytest

from common.api_client import ShopApi, ok


@allure.feature("用例设计")
@allure.title("同一商品写成两行会合并成一行，库存一次扣掉两件")
@pytest.mark.smoke
def test_same_product_lines_merge(api, product):
    stock_before = ok(api.get_product(product["id"]))["stock"]
    items = [
        {"productId": product["id"], "quantity": 1},
        {"productId": product["id"], "quantity": 1},
    ]
    order = ok(api.create_order(items))
    try:
        lines = ok(api.get_order(order["orderNo"]))["items"]
        assert [line["quantity"] for line in lines] == [2]     # 两行合成了一行，数量是 2
        assert ok(api.get_product(product["id"]))["stock"] == stock_before - 2
    finally:
        ok(api.cancel_order(order["orderNo"]))


@allure.feature("用例设计")
@allure.title("一单买两种商品，订单金额是两行小计之和")
def test_two_products_one_order(api):
    pen = ok(api.search_products(keyword="中性笔"))["items"][0]
    cup = ok(api.search_products(keyword="马克杯"))["items"][0]
    order = ok(api.create_order([
        {"productId": pen["id"], "quantity": 2},
        {"productId": cup["id"], "quantity": 1},
    ]))
    try:
        assert order["amount"] == pytest.approx(pen["price"] * 2 + cup["price"] * 1)
    finally:
        ok(api.cancel_order(order["orderNo"]))


@allure.feature("用例设计")
@allure.title("下单时库存已锁定：剩下的被别人买光，也不影响我支付")
def test_stock_locked_at_order_time(config):
    """这条用例每跑一次消耗 1 个手办（别人那单会退回）。库存不足 3 件时跳过，
    重启练习网站把数据恢复成初始状态后再跑。"""
    shop = ShopApi(config["base_url"])
    figure = ok(shop.search_products(keyword="限量版手办"))["items"][0]
    stock_before = figure["stock"]
    if stock_before < 3:
        pytest.skip("手办库存不足 3 件，重启练习网站恢复数据后再跑")

    mine = ShopApi(config["base_url"])            # user002 先下单，锁住 1 件
    ok(mine.login("user002", "test123"))
    my_order = ok(mine.create_order([{"productId": figure["id"], "quantity": 1}]))

    other = ShopApi(config["base_url"])           # bob 把剩下的全部买走
    ok(other.login("bob", "bob123"))
    other_order = ok(other.create_order([{"productId": figure["id"], "quantity": stock_before - 1}]))
    try:
        assert ok(shop.get_product(figure["id"]))["stock"] == 0    # 前提：剩下的确实被买光了
        body = mine.pay_order(my_order["orderNo"]).json()
        assert body["code"] == 0, f"库存在下单时已经锁定，支付不该失败：{body}"
    finally:
        ok(other.cancel_order(other_order["orderNo"]))             # bob 那单退掉，只消耗我买的 1 件
        if ok(mine.get_order(my_order["orderNo"]))["status"] == "UNPAID":
            ok(mine.cancel_order(my_order["orderNo"]))             # 我没付成，也退掉


@allure.feature("用例设计")
@allure.title("余额边界：买到刚好付得起的最大台数，支付成功")
def test_pay_max_affordable(config):
    """余额边界的里侧。外侧（多买一台就付不起）是第 4 章的 test_pay_balance_not_enough。

    用账号池里的 user001，别把主账号的余额花光。每跑一次把 user001 的余额花到
    不足一台显示器，重启练习网站恢复数据后可以再跑。"""
    user = ShopApi(config["base_url"])
    ok(user.login("user001", "test123"))
    balance = ok(user.me())["balance"]
    monitor = ok(user.search_products(keyword="显示器"))["items"][0]   # 1299 元一台
    quantity = int(balance // monitor["price"])    # 付得起的最大台数（// 是整除）
    if quantity < 1:
        pytest.skip("user001 余额不足一台显示器，重启练习网站恢复数据后再跑")

    order = ok(user.create_order([{"productId": monitor["id"], "quantity": quantity}]))
    body = user.pay_order(order["orderNo"]).json()
    if body["code"] != 0:
        ok(user.cancel_order(order["orderNo"]))    # 没付出去就还掉库存，再报失败
    assert body["code"] == 0, f"余额 {balance} 元买 {quantity} 台应该付得起：{body}"
