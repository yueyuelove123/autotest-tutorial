"""判定表的用例：登录接口，用户名、密码各取真假两种，一共六种组合。

判定表见教程第 5 章 5.3 节：先在表格里把条件组合和预期动作列全，再翻译成参数化用例。
登录类用例统一用 bob，不碰主账号。
"""
import allure
import pytest

from common.api_client import ok

# (场景名, 用户名, 密码, 预期业务码, 预期提示)。
# 「账号不存在」和「密码错误」服务器都回同一种失败（防止被人试出账号），
# 所以判定表里合成「用户名错误」一行；想分开测，预期也是一样的
LOGIN_DECISION_TABLE = [
    ("用户名密码都为空", "", "", 1002, "用户名和密码不能为空"),
    ("只有用户名为空", "", "bob123", 1002, "用户名和密码不能为空"),
    ("只有密码为空", "bob", "", 1002, "用户名和密码不能为空"),
    ("用户名错误", "nobody", "bob123", 1001, "用户名或密码错误"),
    ("密码错误", "bob", "wrong-password", 1001, "用户名或密码错误"),
]


@allure.feature("用例设计")
@allure.title("登录判定表：{title}")
@pytest.mark.parametrize(
    "title, username, password, code, msg",
    LOGIN_DECISION_TABLE,
    ids=[c[0] for c in LOGIN_DECISION_TABLE],
)
def test_login_decision_table(guest, title, username, password, code, msg):
    resp = guest.login(username, password)
    assert resp.status_code == 200
    body = resp.json()
    assert body["code"] == code
    assert body["msg"] == msg
    assert body["data"] is None


@allure.feature("用例设计")
@allure.title("登录判定表：用户名密码都对，登录成功返回 token")
def test_login_all_correct(guest):
    data = ok(guest.login("bob", "bob123"))
    assert data["username"] == "bob"
    assert len(data["token"]) == 32
