"""异步任务的用例：库存报表要先提交、再轮询、最后下载。"""
import csv
import io

import allure
import pytest

from common.api_client import ShopApi, ok


@allure.feature("库存报表")
@allure.title("库存报表：提交任务，等它跑完，下载到 25 件商品的库存")
def test_stock_report(api):
    task_id = ok(api.create_stock_report())["taskId"]
    task = api.wait_task(task_id)
    assert task["finishedAt"] is not None
    resp = api.download_task(task_id)
    assert resp.status_code == 200
    assert resp.headers["Content-Disposition"] == f"attachment; filename={task_id}.csv"
    rows = list(csv.DictReader(io.StringIO(resp.content.decode("utf-8-sig"))))
    assert len(rows) == 25
    assert all(row["商品编号"].startswith("SKU") for row in rows)


@allure.feature("库存报表")
@allure.title("任务还没跑完就去下载，返回 6002")
def test_download_before_done(api):
    task_id = ok(api.create_stock_report())["taskId"]
    body = api.download_task(task_id).json()
    assert body["code"] == 6002
    assert body["msg"] == "任务还没跑完，稍后再来下载"


@pytest.fixture
def bob(config):
    client = ShopApi(config["base_url"], timeout=config["timeout"])
    ok(client.login("bob", "bob123"))
    return client


@allure.feature("库存报表")
@allure.title("别人提交的任务查不到也下载不了，返回 6001")
def test_task_belongs_to_owner(api, bob):
    task_id = ok(api.create_stock_report())["taskId"]
    for resp in (bob.get_task(task_id), bob.download_task(task_id)):
        assert resp.json()["code"] == 6001
