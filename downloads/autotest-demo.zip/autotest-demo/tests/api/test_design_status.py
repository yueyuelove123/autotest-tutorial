"""状态迁移的用例：订单有 待支付、已支付、已取消 三种状态。

合法迁移只有两条：待支付→已支付（支付）、待支付→已取消（取消）；
已支付和已取消都是终态，再对它们做任何操作都该被拒绝。
每条用例自己下一单，不依赖别的用例留下的状态，避免「订单被上一条用例支付了」这种错位。
"""
import allure
import pytest

from common.api_client import ok


@allure.feature("用例设计")
@allure.title("合法迁移：待支付订单支付后变为已支付，余额扣减")
@pytest.mark.smoke
def test_unpaid_to_paid(api, unpaid_order):
    balance_before = ok(api.me())["balance"]
    data = ok(api.pay_order(unpaid_order["orderNo"]))
    assert data["status"] == "PAID"
    assert data["balance"] == pytest.approx(balance_before - unpaid_order["amount"])
    detail = ok(api.get_order(unpaid_order["orderNo"]))
    assert detail["status"] == "PAID"
    assert detail["paidAt"] is not None


@allure.feature("用例设计")
@allure.title("合法迁移：待支付订单取消后变为已取消，库存归还")
def test_unpaid_to_cancelled(api, product):
    stock_before = ok(api.get_product(product["id"]))["stock"]
    order = ok(api.create_order([{"productId": product["id"], "quantity": 2}]))
    data = ok(api.cancel_order(order["orderNo"]))
    assert data["status"] == "CANCELLED"
    assert ok(api.get_product(product["id"]))["stock"] == stock_before


# 非法迁移表：(场景名, 先做什么把订单推到终态, 再做什么, 预期提示)
ILLEGAL_TRANSITIONS = [
    ("已支付再支付", "支付", "支付", "订单已支付，不能支付"),
    ("已支付再取消", "支付", "取消", "订单已支付，不能取消"),
    ("已取消再支付", "取消", "支付", "订单已取消，不能支付"),
    ("已取消再取消", "取消", "取消", "订单已取消，不能取消"),
]


@allure.feature("用例设计")
@allure.title("非法迁移被拒绝：{title}")
@pytest.mark.parametrize("title, first, then, msg", ILLEGAL_TRANSITIONS, ids=[c[0] for c in ILLEGAL_TRANSITIONS])
def test_illegal_transition(api, unpaid_order, title, first, then, msg):
    actions = {"支付": api.pay_order, "取消": api.cancel_order}
    ok(actions[first](unpaid_order["orderNo"]))           # 先把订单推到终态
    body = actions[then](unpaid_order["orderNo"]).json()  # 再做一次不允许的操作
    assert body["code"] == 3003
    assert body["msg"] == msg


NO_SUCH_ORDER = "SO20991231000001"   # 一张永远不会存在的订单号
NOT_FOUND_ACTIONS = ["查询", "支付", "取消"]


@allure.feature("用例设计")
@allure.title("不存在的订单号：{action}返回 3001")
@pytest.mark.parametrize("action", NOT_FOUND_ACTIONS, ids=[f"{a}不存在的订单" for a in NOT_FOUND_ACTIONS])
def test_order_not_found(api, action):
    actions = {"查询": api.get_order, "支付": api.pay_order, "取消": api.cancel_order}
    body = actions[action](NO_SUCH_ORDER).json()
    assert body["code"] == 3001
    assert body["msg"] == "订单不存在"
