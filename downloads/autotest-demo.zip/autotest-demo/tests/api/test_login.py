"""登录接口的用例。"""
from pathlib import Path

import allure
import pytest
import yaml

from common.api_client import ShopApi, ok

CASES = yaml.safe_load((Path(__file__).parents[2] / "data" / "login_cases.yaml").read_text(encoding="utf-8"))


@allure.feature("账号")
@allure.title("正确的用户名和密码可以登录")
@pytest.mark.smoke
def test_login_success(guest, config):
    acc = config["accounts"]["login"]
    data = ok(guest.login(acc["username"], acc["password"]))
    assert data["username"] == acc["username"]
    assert len(data["token"]) == 32


@allure.feature("账号")
@pytest.mark.parametrize("case", CASES, ids=[c["title"] for c in CASES])
def test_login_fail(guest, case):
    allure.dynamic.title(f"登录失败：{case['title']}")
    resp = guest.login(case["username"], case["password"])
    assert resp.status_code == 200
    body = resp.json()
    assert body["code"] == case["code"]
    assert body["msg"] == case["msg"]
    assert body["data"] is None


@allure.feature("账号")
@allure.title("请求体缺少密码字段时返回参数错误")
def test_login_missing_field(guest):
    resp = guest.request("POST", "/api/login", json={"username": "bob"})
    assert resp.status_code == 422
    assert resp.json()["data"] == [{"field": "password", "reason": "Field required"}]


@allure.feature("账号")
@allure.title("不带 token 访问需要登录的接口返回 401")
def test_requires_token(guest):
    resp = guest.me()
    assert resp.status_code == 401
    assert resp.json()["code"] == 40101    # 业务码区分：40101 是没登录，40102 是登录过期


@allure.feature("账号")
@allure.title("退出登录后原来的 token 失效")
def test_logout_invalidates_token(config):
    acc = config["accounts"]["login"]
    client = ShopApi(config["base_url"])
    ok(client.login(acc["username"], acc["password"]))
    ok(client.logout())
    assert client.me().status_code == 401
