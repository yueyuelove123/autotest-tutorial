"""下单、支付、取消的用例。数据都由夹具现造现清，用例之间互不依赖。"""
import allure
import pytest

from common.api_client import ShopApi, ok


@allure.feature("订单")
@allure.title("完整购买流程：下单、支付，余额和库存都对得上")
@pytest.mark.smoke
def test_purchase_flow(api, product):
    with allure.step("记下余额和库存"):
        balance_before = ok(api.me())["balance"]
        stock_before = ok(api.get_product(product["id"]))["stock"]
    with allure.step("下单 3 件"):
        order = ok(api.create_order([{"productId": product["id"], "quantity": 3}]))
        assert order["status"] == "UNPAID"
        assert order["amount"] == pytest.approx(product["price"] * 3)
        assert ok(api.get_product(product["id"]))["stock"] == stock_before - 3
    with allure.step("支付"):
        paid = ok(api.pay_order(order["orderNo"]))
        assert paid["status"] == "PAID"
    with allure.step("核对订单状态和余额"):
        detail = ok(api.get_order(order["orderNo"]))
        assert detail["status"] == "PAID"
        assert detail["paidAt"] is not None
        assert ok(api.me())["balance"] == pytest.approx(balance_before - order["amount"])


@allure.feature("订单")
@allure.title("下单数量超过库存时返回库存不足，库存不变")
def test_create_order_stock_not_enough(api):
    figure = ok(api.search_products(keyword="限量版手办"))["items"][0]   # 只有 3 个库存
    body = api.create_order([{"productId": figure["id"], "quantity": figure["stock"] + 1}]).json()
    assert body["code"] == 2002
    assert ok(api.get_product(figure["id"]))["stock"] == figure["stock"]


INVALID_ITEMS = [
    ("商品列表为空", []),
    ("数量为0", [{"productId": 13, "quantity": 0}]),
    ("数量超过999", [{"productId": 13, "quantity": 1000}]),
]


@allure.feature("订单")
@allure.title("下单参数非法时返回 422：{title}")
@pytest.mark.parametrize("title, items", INVALID_ITEMS, ids=[c[0] for c in INVALID_ITEMS])
def test_create_order_invalid(api, title, items):
    resp = api.create_order(items)
    assert resp.status_code == 422


@allure.feature("订单")
@allure.title("支付成功后订单变为已支付，余额扣减订单金额")
def test_pay_order(api, unpaid_order):
    balance_before = ok(api.me())["balance"]
    data = ok(api.pay_order(unpaid_order["orderNo"]))
    assert data["status"] == "PAID"
    assert data["balance"] == pytest.approx(balance_before - unpaid_order["amount"])


@allure.feature("订单")
@allure.title("同一订单重复支付会被拒绝，只扣一次钱")
def test_pay_twice_rejected(api, unpaid_order):
    balance_before = ok(api.me())["balance"]
    ok(api.pay_order(unpaid_order["orderNo"]))
    body = api.pay_order(unpaid_order["orderNo"]).json()
    assert body["code"] == 3003
    assert ok(api.me())["balance"] == pytest.approx(balance_before - unpaid_order["amount"])


@allure.feature("订单")
@allure.title("余额不足时支付失败，订单还是待支付")
def test_pay_balance_not_enough(api):
    monitor = ok(api.search_products(keyword="显示器"))["items"][0]   # 1299 元一台
    balance = ok(api.me())["balance"]
    quantity = int(balance // monitor["price"]) + 1                  # 买到刚好超过余额
    if quantity > 999:
        pytest.skip("余额太多，单行最多 999 件，凑不出超过余额的金额")
    order = ok(api.create_order([{"productId": monitor["id"], "quantity": quantity}]))
    try:
        body = api.pay_order(order["orderNo"]).json()
        assert body["code"] == 3002
        assert ok(api.get_order(order["orderNo"]))["status"] == "UNPAID"
        assert ok(api.me())["balance"] == pytest.approx(balance)
    finally:
        ok(api.cancel_order(order["orderNo"]))   # 不管断言过没过，都把占用的库存还回去


@allure.feature("订单")
@allure.title("取消订单后库存归还，订单不能再支付")
def test_cancel_order(api, product):
    stock_before = ok(api.get_product(product["id"]))["stock"]
    order = ok(api.create_order([{"productId": product["id"], "quantity": 2}]))
    ok(api.cancel_order(order["orderNo"]))
    assert ok(api.get_order(order["orderNo"]))["status"] == "CANCELLED"
    assert ok(api.get_product(product["id"]))["stock"] == stock_before
    assert api.pay_order(order["orderNo"]).json()["code"] == 3003


@allure.feature("订单")
@allure.title("看不到别人的订单")
def test_cannot_see_others_order(api, config, unpaid_order):
    acc = config["accounts"]["login"]
    other = ShopApi(config["base_url"])
    ok(other.login(acc["username"], acc["password"]))
    assert other.get_order(unpaid_order["orderNo"]).json()["code"] == 3001
    assert other.pay_order(unpaid_order["orderNo"]).json()["code"] == 3001
