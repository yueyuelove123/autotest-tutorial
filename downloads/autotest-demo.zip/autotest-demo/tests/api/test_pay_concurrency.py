"""并发支付：同一张订单被同时支付多次，钱只能扣一次。

练习网站默认没有这个缺陷，这条用例会通过。用 SHOP_PAY_RACE_BUG=1 重启练习网站，
它就会失败，这就是并发测试能发现、单线程测试发现不了的那类资金问题。
"""
import threading
from concurrent.futures import ThreadPoolExecutor

import allure
import pytest

from common.api_client import ShopApi, ok

THREADS = 10


@allure.feature("订单")
@allure.title("同一订单并发支付 10 次，只成功 1 次、只扣 1 次钱")
@pytest.mark.concurrency
def test_concurrent_pay_deducts_once(api, config, unpaid_order):
    balance_before = ok(api.me())["balance"]
    barrier = threading.Barrier(THREADS)   # 10 个线程都准备好了再一起发，尽量撞在同一时刻

    def pay_once(_):
        client = ShopApi(config["base_url"])           # 每个线程用自己的连接
        client.session.headers["token"] = api.token    # 同一个登录态，相当于同一个人连点支付
        barrier.wait()
        return client.pay_order(unpaid_order["orderNo"]).json()["code"]

    with ThreadPoolExecutor(max_workers=THREADS) as pool:
        codes = list(pool.map(pay_once, range(THREADS)))

    balance_after = ok(api.me())["balance"]
    assert codes.count(0) == 1, f"应该只有 1 次支付成功，实际返回的业务码：{codes}"
    assert balance_after == pytest.approx(balance_before - unpaid_order["amount"]), (
        f"余额应该只扣 1 次：支付前 {balance_before}，支付后 {balance_after}，订单金额 {unpaid_order['amount']}"
    )
