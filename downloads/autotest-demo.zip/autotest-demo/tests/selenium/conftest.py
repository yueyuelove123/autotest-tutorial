"""Selenium 用例的夹具。Selenium 没有官方的 pytest 插件，浏览器的启动和关闭自己写。"""
import os

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait


@pytest.fixture
def driver():
    """每条用例一个新浏览器，用完关掉。

    环境变量 CHROMEDRIVER 指向手动下载的 chromedriver.exe；没设就交给 Selenium 自己找（12.2 节）。
    默认无头运行（不弹窗口），想看着它跑就设环境变量 HEADED=1。
    """
    path = os.getenv("CHROMEDRIVER")
    options = webdriver.ChromeOptions()
    if os.getenv("HEADED") != "1":
        options.add_argument("--headless=new")
    d = webdriver.Chrome(service=Service(path) if path else Service(), options=options)
    yield d
    d.quit()


@pytest.fixture
def wait(driver):
    """显式等待的工具：wait.until(条件)，最多等 10 秒。"""
    return WebDriverWait(driver, 10)


@pytest.fixture
def logged_in(driver, wait, base_url, account):
    """已登录、停在商品页的浏览器。"""
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as ec

    driver.get(f"{base_url}/login.html")
    driver.find_element(By.ID, "username").send_keys(account["username"])
    driver.find_element(By.ID, "password").send_keys(account["password"])
    driver.find_element(By.CSS_SELECTOR, "button[type=submit]").click()
    wait.until(ec.url_contains("/products.html"))
    # 再等首屏的商品列表加载出来：页面准备好了再交给用例，免得用例在页面没就绪时就开始操作
    wait.until(lambda d: d.find_elements(By.CSS_SELECTOR, "#rows tr"))
    return driver
