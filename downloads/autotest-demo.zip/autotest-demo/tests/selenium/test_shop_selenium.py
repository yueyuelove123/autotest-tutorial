"""用 Selenium 写的三条用例，和第 8、11 章 Playwright 写的同类用例对照着看。"""
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec

ROWS = (By.CSS_SELECTOR, "#rows tr")


def test_login_shows_welcome(logged_in, account):
    assert logged_in.find_element(By.ID, "welcome").text == f"欢迎，{account['username']}"


def test_search_headphones(logged_in, wait):
    logged_in.find_element(By.ID, "keyword").send_keys("耳机")
    logged_in.find_element(By.CSS_SELECTOR, "#search-form button[type=submit]").click()
    wait.until(lambda d: len(d.find_elements(*ROWS)) == 2)      # 等列表刷新成 2 行
    assert all("耳机" in row.text for row in logged_in.find_elements(*ROWS))


def test_confirm_dismiss(driver, wait, base_url):
    driver.get(f"{base_url}/lab.html")
    driver.find_element(By.ID, "btn-confirm").click()
    wait.until(ec.alert_is_present()).dismiss()
    wait.until(ec.text_to_be_present_in_element((By.ID, "result"), "你点了取消"))
