"""工厂夹具：夹具返回一个造数函数，用例要几张造几张。"""
import pytest

from common.api_client import ok


@pytest.fixture
def make_order(api, product):
    """造单工厂：调用一次造一张待支付订单。造出来的单在清理阶段统一处理。"""
    made = []

    def _make(quantity=1):
        order = ok(api.create_order([{"productId": product["id"], "quantity": quantity}]))
        made.append(order)
        return order

    yield _make
    for order in made:   # 清理：只有还没支付的才需要取消，把库存还回去
        if ok(api.get_order(order["orderNo"]))["status"] == "UNPAID":
            ok(api.cancel_order(order["orderNo"]))


def test_pay_one_leave_others_cancellable(api, make_order):
    """一次造 3 张单：支付其中 1 张，另外 2 张还能取消。"""
    orders = [make_order(), make_order(quantity=2), make_order(quantity=3)]
    assert len({o["amount"] for o in orders}) == 3       # 数量不同，金额也各不相同

    paid = ok(api.pay_order(orders[0]["orderNo"]))
    assert paid["status"] == "PAID"

    for order in orders[1:]:
        data = ok(api.cancel_order(order["orderNo"]))
        assert data["status"] == "CANCELLED"
    body = api.pay_order(orders[1]["orderNo"]).json()
    assert body["code"] == 3003                          # 已取消的订单不能再支付
