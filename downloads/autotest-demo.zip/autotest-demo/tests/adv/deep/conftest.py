"""更深一层目录的 conftest.py：它定义的夹具只对 tests/adv/deep 里的用例生效。"""
import pytest


@pytest.fixture
def who():
    return "tests/adv/deep 的 conftest.py"
