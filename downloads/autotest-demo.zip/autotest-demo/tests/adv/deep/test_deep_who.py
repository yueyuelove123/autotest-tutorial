"""同名的夹具，深层目录里的用例用到的是更深那一层的版本。"""


def test_who(who):
    assert who == "tests/adv/deep 的 conftest.py"
