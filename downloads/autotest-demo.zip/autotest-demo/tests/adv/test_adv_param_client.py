"""参数化夹具：一条用例跑三种登录态。guest 在本目录被参数化成三种客户端。"""
from common.api_client import ok


def test_access_me(guest, api):
    """合法 token 能查到自己的信息；假 token、不带 token 都要被挡在门外。"""
    resp = guest.me()
    if resp.status_code == 200:
        body = ok(resp)
        assert body["username"] == api.username   # 合法 token 借用的是 api 夹具的登录态
    else:
        assert resp.status_code == 401
        assert resp.json()["code"] == 40101    # 40101 是没登录或 token 无效
