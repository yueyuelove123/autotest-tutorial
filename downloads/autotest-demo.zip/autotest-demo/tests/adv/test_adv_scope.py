"""作用域实验：加 -s 运行，看两个夹具各被创建了几次。"""
import pytest


@pytest.fixture(scope="session")
def session_box():
    print("\n创建 session_box")
    return {}


@pytest.fixture
def function_box():
    print("\n创建 function_box")
    return {}


@pytest.mark.parametrize("n", [1, 2, 3])
def test_scope(n, session_box, function_box):
    assert session_box == {} and function_box == {}
