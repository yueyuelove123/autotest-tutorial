"""monkeypatch：用例里临时改环境变量、临时换掉函数，用例结束自动还原。"""
import pytest

from common.api_client import ok
from common.config import load_config


def test_config_reads_chosen_env(monkeypatch):
    """临时把环境名换成 staging：配置文件不存在时，报错要说清楚是哪个文件没找到。"""
    load_config.cache_clear()                     # 配置读一次就会缓存，先清掉再实验
    monkeypatch.setenv("TEST_ENV", "staging")
    with pytest.raises(FileNotFoundError) as exc_info:
        load_config()
    assert "staging.yaml" in str(exc_info.value)


class FakeResponse:
    """假的接口返回：只实现业务函数用到的部分。"""

    def __init__(self, data):
        self.status_code = 200
        self.text = str(data)
        self._data = data

    def json(self):
        return {"code": 0, "msg": "ok", "data": self._data}


def order_summary(api):
    """业务函数：把订单列表整理成一句话。它只依赖 api.list_orders() 的返回。"""
    data = ok(api.list_orders())
    if not data["items"]:
        return "还没有订单"
    latest = data["items"][0]["orderNo"]
    return f"共 {data['total']} 张订单，最新一张是 {latest}"


def test_order_summary_with_fake_return(api, monkeypatch):
    """把 list_orders 换成假返回：不用真的下单，也能测业务函数。"""
    fake = FakeResponse({"total": 2, "items": [{"orderNo": "ORD0001"}, {"orderNo": "ORD0002"}]})
    monkeypatch.setattr(api, "list_orders", lambda status=None: fake)
    assert order_summary(api) == "共 2 张订单，最新一张是 ORD0001"


def test_order_summary_back_to_real(api, unpaid_order):
    """上一条用例结束后 list_orders 已经自动还原：能查到夹具刚造的那张单。"""
    assert unpaid_order["orderNo"] in order_summary(api)
