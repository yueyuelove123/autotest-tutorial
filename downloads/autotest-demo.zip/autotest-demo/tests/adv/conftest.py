"""tests/adv 目录专用的夹具和钩子。放在哪一层，就对哪一层（含子目录）的用例生效。"""
import time

import pytest

from common.api_client import ShopApi


# ---------- 同名夹具就近覆盖的实验：本层定义了 who，更深一层的 conftest 又覆盖了它 ----------
@pytest.fixture
def who():
    return "tests/adv 的 conftest.py"


# ---------- 参数化夹具：把客户端参数化成三种登录态（覆盖了外层的 guest，只对本目录生效）----------
@pytest.fixture(params=[("合法token", True), ("假token", False), ("不带token", False)],
                ids=["合法token", "假token", "不带token"])
def guest(request, config, api):
    """本目录专用的客户端：同一个夹具名，按参数造出三种登录态的客户端。"""
    kind, _ = request.param
    client = ShopApi(config["base_url"], timeout=config["timeout"])
    if kind == "合法token":
        client.session.headers["token"] = api.token    # 借用 api 夹具的登录态
    elif kind == "假token":
        client.session.headers["token"] = "deadbeef" * 4
    return client


# ---------- autouse 夹具：自动给每条用例记接口耗时，失败时打印 ----------
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """把每条用例各阶段的结果记到用例对象上，夹具在清理阶段才能知道用例有没有失败。"""
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f"rep_{rep.when}", rep)


@pytest.fixture(autouse=True)
def watch_api(request, api):
    """自动对每条用例生效：记下它发过的每个接口请求，失败时把最慢的几个打印出来。"""
    calls = []
    original = api.request

    def timed_request(method, path, **kwargs):
        start = time.perf_counter()
        resp = original(method, path, **kwargs)
        calls.append((f"{method} {path}", (time.perf_counter() - start) * 1000))
        return resp

    api.request = timed_request
    yield
    api.request = original
    rep = getattr(request.node, "rep_call", None)
    if rep is not None and rep.failed and calls:
        print("\n这条用例发过的接口请求，按耗时排最慢的 3 个：")
        for name, ms in sorted(calls, key=lambda c: c[1], reverse=True)[:3]:
            print(f"  {ms:6.0f} 毫秒  {name}")
