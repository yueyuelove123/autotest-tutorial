"""同名的夹具，用例用到的到底是哪一层定义的？跑一跑就知道。"""


def test_who(who):
    assert who == "tests/adv 的 conftest.py"
