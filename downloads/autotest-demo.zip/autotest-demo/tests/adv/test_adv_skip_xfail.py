"""skip 和 xfail：环境不满足就跳过；已知缺陷先做标记，修好了会大声提醒。"""
import os
import threading
from concurrent.futures import ThreadPoolExecutor

import pytest

from common.api_client import ShopApi, ok


@pytest.mark.skipif(os.getenv("SHOP_PAY_RACE_BUG") != "1",
                    reason="要观察这个缺陷，得用 SHOP_PAY_RACE_BUG=1 重启练习网站")
def test_pay_race_duplicated_deduction(api, config, unpaid_order):
    """在带缺陷的网站上，并发支付会成功多次、余额被多扣。"""
    balance_before = ok(api.me())["balance"]
    barrier = threading.Barrier(5)

    def pay_once(_):
        client = ShopApi(config["base_url"])
        client.session.headers["token"] = api.token
        barrier.wait()
        return client.pay_order(unpaid_order["orderNo"]).json()["code"]

    with ThreadPoolExecutor(max_workers=5) as pool:
        codes = list(pool.map(pay_once, range(5)))

    balance_after = ok(api.me())["balance"]
    assert codes.count(0) > 1, f"缺陷网站上应该有不止一次支付成功，实际：{codes}"
    assert balance_after < balance_before - unpaid_order["amount"], "缺陷网站上余额会被多扣"


def apply_discount(amount, percent):
    """打折工具：percent 是减掉的百分比，比如 20 表示打八折。

    已知缺陷：计算结果用 int() 截断，丢了小数部分（缺陷单 #1024，开发还没修）。
    """
    return int(amount * (100 - percent) / 100)


@pytest.mark.xfail(reason="缺陷 #1024：折扣金额被截断丢了小数，开发修复后这条会变成 XPASS", strict=True)
def test_apply_discount_keeps_cents():
    assert apply_discount(199.0, 20) == pytest.approx(159.2)
