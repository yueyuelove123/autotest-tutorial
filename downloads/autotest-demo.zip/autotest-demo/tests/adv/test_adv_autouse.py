"""autouse 夹具的效果：这条用例没有写 watch_api 参数，它也会自动生效。"""
from common.api_client import ok


def test_me_still_works(api):
    data = ok(api.me())
    assert data["username"] == api.username
