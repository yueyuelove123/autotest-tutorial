"""订单页的 UI 用例：订单用接口造好，页面只验页面上的操作和展示。"""
import allure
import pytest
from playwright.sync_api import expect

from common.api_client import ok
from pages.orders_page import OrdersPage


@allure.feature("UI-订单")
@allure.title("在订单页支付待支付订单，状态变成已支付，余额减少")
@pytest.mark.smoke
def test_pay_in_page(logged_in_page, api, unpaid_order):
    order_no = unpaid_order["orderNo"]
    balance_before = ok(api.me())["balance"]
    orders = OrdersPage(logged_in_page).open()
    expect(orders.row(order_no)).to_contain_text("待支付")

    orders.pay(order_no)

    expect(orders.toast).to_contain_text(f"支付成功，订单号：{order_no}")
    expect(orders.row(order_no)).to_contain_text("已支付")
    expect(orders.row(order_no).get_by_role("button", name="支付")).to_have_count(0)
    expect(orders.balance).to_have_text(f"余额：¥{balance_before - unpaid_order['amount']:.2f}")
    assert ok(api.get_order(order_no))["status"] == "PAID"     # 再用接口核对后台数据


@allure.feature("UI-订单")
@allure.title("在订单页取消订单，确认弹窗后状态变成已取消")
def test_cancel_in_page(logged_in_page, api, unpaid_order):
    order_no = unpaid_order["orderNo"]
    orders = OrdersPage(logged_in_page).open()

    orders.cancel(order_no)

    expect(orders.row(order_no)).to_contain_text("已取消")
    assert ok(api.get_order(order_no))["status"] == "CANCELLED"


@allure.feature("UI-订单")
@allure.title("按状态筛选「已取消」，列表里只剩已取消的订单")
def test_filter_by_status(logged_in_page, api, product):
    order = ok(api.create_order([{"productId": product["id"], "quantity": 1}]))
    ok(api.cancel_order(order["orderNo"]))           # 用接口造一张已取消的订单
    orders = OrdersPage(logged_in_page).open()

    orders.filter_by_status("已取消")

    expect(orders.row(order["orderNo"])).to_be_visible()
    expect(orders.rows.filter(has_text="待支付")).to_have_count(0)
    expect(orders.rows.filter(has_text="已支付")).to_have_count(0)
