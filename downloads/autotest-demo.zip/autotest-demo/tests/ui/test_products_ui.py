"""商品页的 UI 用例。"""
import allure
import pytest
from playwright.sync_api import expect

from common.api_client import ok
from pages.products_page import ProductsPage


@allure.feature("UI-商品")
@allure.title("搜索「耳机」，列表里只剩两款耳机")
def test_search(logged_in_page):
    products = ProductsPage(logged_in_page).open()
    products.search("耳机")
    expect(products.rows).to_have_count(2)        # 会自动等列表刷新，不用 sleep
    expect(products.rows.first).to_contain_text("耳机")


@allure.feature("UI-商品")
@allure.title("在页面上购买，提示下单成功，后台生成待支付订单")
@pytest.mark.smoke
def test_buy_from_page(logged_in_page, api, product):
    page = logged_in_page
    products = ProductsPage(page).open()
    products.search(product["name"])
    # 一边点按钮，一边等下单接口的响应，从响应里拿订单号
    with page.expect_response(lambda r: r.url.endswith("/api/orders") and r.request.method == "POST") as info:
        products.buy(product["name"], quantity=2)
    order_no = info.value.json()["data"]["orderNo"]
    try:
        expect(products.toast).to_contain_text(f"下单成功，订单号：{order_no}")
        expect(products.dialog).to_be_hidden()
        # 页面说成功不算数，再用接口核对后台数据
        order = ok(api.get_order(order_no))
        assert order["status"] == "UNPAID"
        assert order["items"][0]["quantity"] == 2
    finally:
        ok(api.cancel_order(order_no))            # 清理：取消订单，归还库存


@allure.feature("UI-商品")
@allure.title("购买数量填 0，弹窗里提示数量范围，不会下单")
def test_buy_invalid_quantity(logged_in_page):
    products = ProductsPage(logged_in_page).open()
    products.search("中性笔")
    products.buy("中性笔", quantity=0)
    expect(products.dialog.get_by_role("alert")).to_have_text("数量要在 1 到 999 之间")
    expect(products.dialog).to_be_visible()


@allure.feature("UI-商品")
@allure.title("商品接口出错时，页面提示加载失败")
def test_load_error(logged_in_page):
    page = logged_in_page
    # 拦截商品接口，直接返回 500，模拟后端出故障（不用真的把服务弄坏）
    page.route("**/api/products*", lambda route: route.fulfill(status=500, body="Internal Server Error"))
    products = ProductsPage(page).open()
    expect(products.state).to_have_text("加载失败，请稍后重试")
    expect(products.rows).to_have_count(0)
