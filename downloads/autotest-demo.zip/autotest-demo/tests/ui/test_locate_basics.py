"""第 9 章的定位示例用例：语义定位、模糊与精确匹配、严格模式、role 的筛选参数。"""
import re

from playwright.sync_api import Page, expect


def test_get_by_role_on_lab(page: Page):
    """get_by_role 在练习场上能找到的各类元素。"""
    page.goto("/lab.html")
    assert page.get_by_role("button").count() == 7           # 顶栏 1 个 + 练习场 6 个
    assert page.get_by_role("heading", level=1).count() == 1
    assert page.get_by_role("heading", level=2).count() == 5
    assert page.get_by_role("checkbox").count() == 1
    assert page.get_by_role("radio").count() == 2
    assert page.get_by_role("combobox").count() == 1
    assert page.get_by_role("link").count() == 5
    # 日期输入框的角色也是 textbox
    assert page.get_by_role("textbox", name="日期").count() == 1


def test_role_filters(page: Page):
    """role 还能带上状态筛选：只勾选了才算 checked，隐藏的 dialog 默认不算数。"""
    page.goto("/lab.html")
    assert page.get_by_role("checkbox", checked=False).count() == 1
    assert page.get_by_role("dialog").count() == 0                    # 购买弹窗在商品页，这里没有
    assert page.get_by_role("dialog", include_hidden=True).count() == 0
    page.get_by_role("checkbox").check()
    assert page.get_by_role("checkbox", checked=True).count() == 1


def test_name_fuzzy_and_exact(page: Page):
    """name= 默认模糊匹配，exact=True 之后连按钮文字里计数的变化都匹配不上了。"""
    page.goto("/lab.html")
    assert page.get_by_role("button", name="双击我").count() == 1
    # 按钮文字是「双击我（0 次）」，完整相等匹配不到
    assert page.get_by_role("button", name="双击我", exact=True).count() == 0
    expect(page.get_by_role("button", name=re.compile(r"双击我（\d+ 次）"))).to_have_count(1)


def test_label_wrapping(page: Page):
    """label 包住控件时，get_by_label 找的是控件；label 里的全部文字都算标签文字。"""
    page.goto("/lab.html")
    assert page.get_by_label("键盘按键", exact=True).count() == 1   # label 里只有一句话 + 输入框
    assert page.get_by_label("日期").count() == 1
    assert page.get_by_label("同意协议").count() == 1
    # 「城市」的 label 里还包着下拉框的全部选项文字，完整相等匹配不上
    assert page.get_by_label("城市").count() == 1
    assert page.get_by_label("城市", exact=True).count() == 0


def test_strict_mode_reported(page: Page):
    """页面上有 7 个按钮，先数清楚，再缩小范围。"""
    page.goto("/lab.html")
    buttons = page.get_by_role("button")
    assert buttons.count() == 7
    # count() 只数当下有多少个，不断言个数时不能拿它当等待
    expect(buttons.filter(has_text="提交")).to_have_count(1)
    expect(page.get_by_test_id("btn-submit")).to_have_count(1)


def test_css_and_filter_on_products(logged_in_page: Page):
    """CSS 选择器与 filter 在商品页上的几个真实例子。"""
    page = logged_in_page
    page.goto("/products.html")
    expect(page.get_by_test_id("product-row")).to_have_count(10)
    assert page.locator("#page-info").inner_text() == "第 1 页，共 25 件商品"
    assert page.locator(".pager button").count() == 2
    assert page.locator("tr[data-testid='product-row']:has-text('耳机')").count() == 2
    assert page.locator("tbody tr:has(button)").count() == 10
    # filter 的四种用法
    rows = page.get_by_test_id("product-row")
    assert rows.filter(has_text="耳机").count() == 2
    assert rows.filter(has_not_text="耳机").count() == 8
    assert rows.filter(has=page.get_by_role("button", name="购买")).count() == 10
    assert rows.filter(
        has_text="鼠标"
    ).or_(rows.filter(has_text="键盘")).count() == 2


def test_first_last_nth(logged_in_page: Page):
    """first / last / nth 取行，行内再用角色定位单元格。"""
    page = logged_in_page
    page.goto("/orders.html")
    rows = page.get_by_test_id("order-row")
    expect(rows.first).to_be_visible()          # 先等列表出来，再谈第几行
    # 每行第一格是订单号
    assert rows.first.get_by_role("cell").nth(0).inner_text().startswith("SO")
    assert rows.last.get_by_role("cell").nth(0).inner_text().startswith("SO")
    # 越界的 nth 匹配 0 个，不会报错
    assert rows.nth(99).count() == 0
