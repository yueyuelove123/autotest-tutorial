"""第 10 章的文件与多页面示例：上传头像、导出 CSV、新标签页、iframe。"""
import struct
import zlib

from playwright.sync_api import Page, expect

from common.api_client import ok


def tiny_png_bytes() -> bytes:
    """现造一个 1×1 的 PNG，不依赖任何图片文件。"""

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00\xff"))
    png += chunk(b"IEND", b"")
    return png


def test_avatar_upload(tmp_path, logged_in_page: Page):
    """set_input_files 直接给文件输入框设置文件，不走系统的文件选择窗口。"""
    page = logged_in_page
    file_path = tmp_path / "avatar.png"
    file_path.write_bytes(tiny_png_bytes())

    page.goto("/profile.html")
    expect(page.get_by_test_id("username-ro")).to_be_visible()
    page.get_by_test_id("avatar-file").set_input_files(str(file_path))
    page.get_by_test_id("avatar-upload").click()
    expect(page.get_by_test_id("avatar-msg")).to_contain_text("上传成功")
    expect(page.get_by_alt_text("头像")).to_be_visible()


def test_avatar_upload_rejects_gif(logged_in_page: Page):
    """格式不对时页面给出提示；文件可以直接在内存里构造，不落盘。"""
    page = logged_in_page
    page.goto("/profile.html")
    expect(page.get_by_test_id("username-ro")).to_be_visible()
    page.get_by_test_id("avatar-file").set_input_files(
        files=[{"name": "avatar.gif", "mimeType": "image/gif", "buffer": b"GIF89a" + b"\x00" * 20}]
    )
    page.get_by_test_id("avatar-upload").click()
    expect(page.get_by_test_id("avatar-msg")).to_have_text("上传失败：头像只支持 jpg 或 png 格式")


def test_export_csv_download(tmp_path, logged_in_page: Page, api, product):
    """expect_download 等到下载开始，读文件内容做断言。"""
    order = ok(api.create_order([{"productId": product["id"], "quantity": 1}]))
    page = logged_in_page
    page.goto("/orders.html")
    expect(page.get_by_test_id("order-row").first).to_be_visible()

    with page.expect_download() as download_info:
        page.get_by_test_id("export").click()
    download = download_info.value
    assert download.suggested_filename == "orders.csv"
    target = tmp_path / download.suggested_filename
    download.save_as(str(target))
    content = target.read_text(encoding="utf-8-sig")
    assert content.splitlines()[0] == "订单号,商品,金额(元),状态,下单时间"
    assert order["orderNo"] in content


def test_new_tab(context, logged_in_page: Page):
    """点开新标签页：先注册 expect_page，再点击，拿到新页面对象。"""
    page = logged_in_page
    page.goto("/lab.html")
    with context.expect_page() as new_page_info:
        page.get_by_test_id("open-tab").click()
    child = new_page_info.value
    child.wait_for_load_state()
    expect(child).to_have_title("子页面 - 迷你商城")
    expect(child.get_by_test_id("from")).to_have_text("link")
    expect(child.get_by_test_id("query")).to_have_text("?from=link")


def test_iframe(logged_in_page: Page):
    """iframe 里的元素要先 frame_locator 进去再定位。"""
    page = logged_in_page
    page.goto("/lab.html")
    frame = page.frame_locator("#inner")
    expect(frame.get_by_test_id("from")).to_have_text("frame")
    expect(frame.get_by_test_id("query")).to_have_text("?from=frame")
    # 也可以先定位 iframe 元素，再用它的 content_frame
    expect(page.get_by_test_id("inner-frame").content_frame.get_by_test_id("from")).to_have_text("frame")
