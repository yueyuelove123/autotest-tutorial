"""UI 用例专用的夹具和钩子。"""
import allure
import pytest


@pytest.fixture
def logged_in_page(page, api, base_url):
    """已登录的页面：把接口登录拿到的 token 种进浏览器，省掉每条用例都走一遍登录页。

    页面会同时检查 token 和 username 两个 cookie，少种一个就当成没登录、跳回登录页。
    """
    page.context.add_cookies([
        {"name": "token", "value": api.token, "url": base_url},
        {"name": "username", "value": api.username, "url": base_url},
    ])
    return page


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """用例失败时截一张整页图，挂进 Allure 报告。"""
    outcome = yield
    report = outcome.get_result()
    page = item.funcargs.get("page")
    if report.when == "call" and report.failed and page is not None:
        allure.attach(page.screenshot(full_page=True), name="失败截图", attachment_type=allure.attachment_type.PNG)
