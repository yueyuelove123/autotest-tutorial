"""第 9 章的表格定位示例：先造一张待支付订单，再在订单页上练 CSS、filter 和 XPath。"""
import re

from playwright.sync_api import Page, expect

from common.api_client import ok


def test_css_and_filter_on_orders(logged_in_page: Page, api, product):
    """按订单号筛行、行内找支付按钮，CSS 与 filter 各写一遍。"""
    order = ok(api.create_order([{"productId": product["id"], "quantity": 1}]))
    no = order["orderNo"]
    page = logged_in_page
    page.goto("/orders.html")
    rows = page.get_by_test_id("order-row")
    expect(rows.first).to_be_visible()

    # CSS 一把梭：属性选择器加上 :has-text()
    assert page.locator(f"tr[data-testid='order-row']:has-text('{no}')").count() == 1
    assert page.locator("[data-testid^='order']").count() == rows.count()
    # filter 的等价写法，推荐这种
    row = rows.filter(has_text=no)
    expect(row).to_have_count(1)
    expect(row.get_by_role("button", name="支付")).to_have_count(1)
    # 带「支付」按钮的行里，属于这张订单的只有一行
    expect(rows.filter(has=page.get_by_role("button", name="支付")).filter(has_text=no)).to_have_count(1)

    # 行内按角色找单元格，第 4 格是状态
    expect(row.get_by_role("cell").nth(3)).to_have_text("待支付")


def test_xpath_on_orders(logged_in_page: Page, api, product):
    """CSS 不好写的场景用 XPath：按文本找行、找兄弟单元格。"""
    order = ok(api.create_order([{"productId": product["id"], "quantity": 1}]))
    no = order["orderNo"]
    page = logged_in_page
    page.goto("/orders.html")
    rows = page.get_by_test_id("order-row")
    expect(rows.first).to_be_visible()

    # 订单号所在行的金额单元格（第 3 格）
    amount = page.locator(f"xpath=//tr[td[1]='{no}']/td[3]")
    expect(amount).to_have_text(f"¥{order['amount']:.2f}")
    # contains() 按部分文本找，第 5 格是下单时间
    created = page.locator(f"xpath=//tr[contains(., '{no}')]/td[5]")
    expect(created).to_have_text(re.compile(r"2026-"))
    # 轴：表头「状态」右边的表头是「下单时间」
    expect(page.locator("xpath=//th[text()='状态']/following-sibling::th[1]")).to_have_text("下单时间")
    # 待支付那一行的操作格里有「支付」「取消」两个按钮（限定在本订单的行里找，避免匹配到别的待支付订单）
    ops = page.locator(f"xpath=//tr[td[1]='{no}']/td[contains(text(),'待支付')]/following-sibling::td[last()]")
    expect(ops).to_contain_text("支付")
