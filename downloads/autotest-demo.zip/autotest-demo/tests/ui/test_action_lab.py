"""第 10 章的页面操作示例：弹窗、悬停、双击、右键、拖动、键盘、表单。"""
import re

from playwright.sync_api import Page, expect


def test_alert_dialog(page: Page):
    """alert 弹窗：读文字、点确定。"""
    page.goto("/lab.html")
    seen = []
    page.once("dialog", lambda d: (seen.append((d.type, d.message)), d.accept()))
    page.get_by_test_id("btn-alert").click()
    assert seen == [("alert", "已保存")]


def test_confirm_accept_and_dismiss(page: Page):
    """confirm 弹窗：accept 是确定，dismiss 是取消，页面会把选择写进 result。"""
    page.goto("/lab.html")
    result = page.get_by_test_id("result")
    page.once("dialog", lambda d: d.accept())
    page.get_by_test_id("btn-confirm").click()
    expect(result).to_have_text("你点了确定")
    page.once("dialog", lambda d: d.dismiss())
    page.get_by_test_id("btn-confirm").click()
    expect(result).to_have_text("你点了取消")


def test_prompt_text_and_default(page: Page):
    """prompt 弹窗：accept 可以带输入的文字；不注册处理函数时默认按取消。"""
    page.goto("/lab.html")
    result = page.get_by_test_id("result")
    page.once("dialog", lambda d: d.accept("小麦"))
    page.get_by_test_id("btn-prompt").click()
    expect(result).to_have_text("你输入了：小麦")
    # 默认行为：自动关掉弹窗，相当于点了取消
    page.get_by_test_id("btn-prompt").click()
    expect(result).to_have_text("你点了取消")


def test_hover_tip(page: Page):
    """悬停出提示，鼠标移开提示消失。"""
    page.goto("/lab.html")
    tip = page.get_by_test_id("tip")
    expect(tip).to_be_hidden()
    page.get_by_test_id("btn-hover").hover()
    expect(tip).to_be_visible()
    page.mouse.move(10, 10)
    expect(tip).to_be_hidden()


def test_dblclick_counter(page: Page):
    """双击计数：dblclick 加 1，连续两次 click 不算双击。"""
    page.goto("/lab.html")
    count = page.get_by_test_id("dblcount")
    page.get_by_test_id("btn-dblclick").dblclick()
    page.get_by_test_id("btn-dblclick").dblclick()
    expect(count).to_have_text("2")
    page.get_by_test_id("btn-dblclick").click()
    page.get_by_test_id("btn-dblclick").click()
    expect(count).to_have_text("2")


def test_right_click_canvas(page: Page):
    """右键点击，页面把坐标写进 context-result。"""
    page.goto("/lab.html")
    page.get_by_test_id("canvas").click(button="right")
    expect(page.get_by_test_id("context-result")).to_contain_text(re.compile(r"右键点了方框（\d+, \d+）"))


def test_mouse_drag_box(page: Page):
    """鼠标拖动三步：move 到方块上、down、move 走过去、up。"""
    page.goto("/lab.html")
    box = page.get_by_test_id("box")
    bb = box.bounding_box()
    page.mouse.move(bb["x"] + 30, bb["y"] + 30)
    page.mouse.down()
    page.mouse.move(bb["x"] + 130, bb["y"] + 80, steps=5)
    page.mouse.up()
    expect(page.get_by_test_id("pos")).not_to_have_text("(0, 0)")


def test_fill_vs_press_sequentially(page: Page):
    """fill 不触发 keydown，press_sequentially 逐字符触发。"""
    page.goto("/lab.html")
    kbd = page.get_by_test_id("kbd")
    key_result = page.get_by_test_id("key-result")
    kbd.fill("hi")
    expect(key_result).to_have_text("")
    kbd.press_sequentially("hi", delay=50)
    expect(key_result).to_have_text("你按了 i")
    kbd.press("Enter")
    expect(key_result).to_have_text("你按了 Enter")


def test_lab_form_flow(page: Page):
    """综合演练：把练习场当成一张完整表单，填完提交并断言结果。"""
    page.goto("/lab.html")
    page.get_by_label("城市").select_option(label="上海")
    page.get_by_label("同意协议").check()
    page.get_by_label("支付宝").check()
    page.get_by_label("日期").fill("2026-10-22")
    page.get_by_test_id("btn-submit").click()
    expect(page.get_by_test_id("form-result")).to_have_text("城市：sh，支付方式：alipay，日期：2026-10-22")


def test_lab_form_blocked_without_agree(page: Page):
    """不勾协议点提交，页面提示要先同意协议，其他选择原样保留。"""
    page.goto("/lab.html")
    page.get_by_label("城市").select_option(label="上海")
    page.get_by_label("支付宝").check()
    page.get_by_test_id("btn-submit").click()
    expect(page.get_by_test_id("form-result")).to_have_text("要先同意协议")
