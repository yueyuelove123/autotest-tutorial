"""登录页的 UI 用例。"""
import re

import allure
import pytest
from playwright.sync_api import expect

from pages.login_page import LoginPage
from pages.products_page import ProductsPage


@allure.feature("UI-登录")
@allure.title("输入正确的账号密码，登录后进入商品页")
@pytest.mark.smoke
def test_login_success(page, config):
    acc = config["accounts"]["login"]
    LoginPage(page).open().login(acc["username"], acc["password"])
    expect(page).to_have_url(re.compile(r"/products\.html$"))
    expect(ProductsPage(page).welcome).to_have_text(f"欢迎，{acc['username']}")


@allure.feature("UI-登录")
@allure.title("密码错误时提示「用户名或密码错误」，停留在登录页")
def test_login_wrong_password(page):
    login = LoginPage(page).open()
    login.login("bob", "wrong-password")
    expect(login.error).to_have_text("用户名或密码错误")
    expect(page).to_have_url(re.compile(r"/login\.html$"))


@allure.feature("UI-登录")
@allure.title("没登录时打开订单页，会被带回登录页")
def test_redirect_when_not_logged_in(page):
    page.goto("/orders.html")
    expect(page).to_have_url(re.compile(r"/login\.html$"))
